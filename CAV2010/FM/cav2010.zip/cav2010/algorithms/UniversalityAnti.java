/* Written by Chen Yu-Fang and Hong Chih-Duo                              */
/* Copyright (c) 2010  Academia Sinica	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package cav2010.algorithms;


import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.TreeSet;

import cav2010.automata.FiniteAutomaton;
import cav2010.automata.FAState;
import cav2010.comparator.GraphComparator;
import cav2010.datastructure.Arc;
import cav2010.datastructure.OneToOneTreeMap;


/**
 * 
 * @author Yu-Fang Chen
 * 
 */
public class UniversalityAnti extends Thread{
	boolean debug=false;

	public int removedCnt;
	public boolean universal=true;
	private TreeMap<String,TreeSet<Integer>> Tail=new TreeMap<String,TreeSet<Integer>>();
	private TreeMap<String,TreeSet<Integer>> Head=new TreeMap<String,TreeSet<Integer>>();
	private long runTime;
	private boolean stop=false;
	private TreeSet<Integer> H, T;
	FiniteAutomaton input;
	public UniversalityAnti(FiniteAutomaton input){
		this.input=input;
	}
	void debug(String out){
		if(debug)
		System.out.println(out);
	}
	
	private boolean lasso_finding_test(TreeSet<Arc> g, TreeSet<Arc> h, int init){
		if(!Head.containsKey(g.toString())){
			H=new TreeSet<Integer>();
			Iterator<Arc> arc_g_it=g.iterator();
			while(arc_g_it.hasNext()){
				Arc arc_g=arc_g_it.next();
				if(arc_g.getFrom()==init){
					H.add(arc_g.getTo());
				}
			}
			Head.put(g.toString(), H);
		}

		if(!Tail.containsKey(h.toString())){
			FiniteAutomaton fa=new FiniteAutomaton();
			OneToOneTreeMap<Integer,FAState> st=new OneToOneTreeMap<Integer,FAState>();
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(!st.containsKey(arc_h.getFrom()))
					st.put(arc_h.getFrom(), fa.createState());
				if(!st.containsKey(arc_h.getTo()))
					st.put(arc_h.getTo(), fa.createState());
				fa.addTransition(st.getValue(arc_h.getFrom()), st.getValue(arc_h.getTo()), arc_h.getLabel()?"1":"0");
			}
			SCC s=new SCC(fa);
			T=new TreeSet<Integer>();
			Iterator<FAState> s_it=s.getResult().iterator();
			while(s_it.hasNext()){
				T.add(st.getKey(s_it.next()));
			}
			int TailSize=0;
			TreeSet<Arc> isolatedArcs=h;
			while(TailSize!=T.size()){
				TailSize=T.size();
				TreeSet<Arc> isolatedArcsTemp=new TreeSet<Arc>();
				Iterator<Arc> arc_it=isolatedArcs.iterator();
				while(arc_it.hasNext()){
					Arc arc=arc_it.next();
					if(!T.contains(arc.getTo())){
						isolatedArcsTemp.add(arc);
					}else{
						T.add(arc.getFrom());
					}
				}
				isolatedArcs=isolatedArcsTemp;
			}
			Tail.put(h.toString(), T);
		}
		TreeSet<Integer> intersection = new TreeSet<Integer>();
		intersection.addAll(Head.get(g.toString()));
		intersection.retainAll(Tail.get(h.toString()));
		if(debug){
			if(intersection.isEmpty()){
				debug("g:"+g+", Head: "+Head.get(g.toString()));
				debug("h:"+h+", Tail: "+Tail.get(h.toString()));
			}
		}
		return !intersection.isEmpty();
	}
	private ArrayList<TreeSet<Arc>> buildSingleCharacterGraphs(){
		ArrayList<TreeSet<Arc>> graphs=new ArrayList<TreeSet<Arc>>();
		
		Iterator<String> symbol_it=input.getAllTransitionSymbols().iterator();
		while(symbol_it.hasNext()){
			TreeSet<Arc> graph=new TreeSet<Arc>();
			
			String sym=symbol_it.next();
			Iterator<cav2010.automata.FAState> from_it=input.states.iterator();
			while(from_it.hasNext()){
				cav2010.automata.FAState from=from_it.next();
				if(from.getNext(sym)!=null){
					Iterator<cav2010.automata.FAState> to_it=from.getNext(sym).iterator();
					while(to_it.hasNext()){
						cav2010.automata.FAState to=to_it.next();
						if(input.F.contains(from)||input.F.contains(to)){
							graph.add(new Arc(from.id,true,to.id));
						}else{
							graph.add(new Arc(from.id,false,to.id));
						}
					}
				}
			}
			ArrayList<TreeSet<Arc>> toRemove=new ArrayList<TreeSet<Arc>>();
			boolean canAdd=true;
			Iterator<TreeSet<Arc>> old_it=graphs.iterator();
			while(old_it.hasNext()){
				TreeSet<Arc> old=old_it.next();
				if(smallerThan(old, graph)){
					canAdd=false;
					break;
				}else if(smallerThan(graph, old)){
					toRemove.add(old);
				}
			}
			if(canAdd){
				graphs.add(graph);
				graphs.removeAll(toRemove);
			}
		}
		return graphs;
	}

	private TreeSet<Arc> compose(TreeSet<Arc> g, TreeSet<Arc> h){
		TreeSet<Arc> f=new TreeSet<Arc>();
		Iterator<Arc> arc_g_it=g.iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(arc_g.getTo()==arc_h.getFrom()){
					if(arc_g.getLabel()||arc_h.getLabel()){
						f.add(new Arc(arc_g.getFrom(),true,arc_h.getTo()));
						f.remove(new Arc(arc_g.getFrom(),false,arc_h.getTo()));
					}else{
						if(!f.contains(new Arc(arc_g.getFrom(),true,arc_h.getTo()))){
							f.add(new Arc(arc_g.getFrom(),false,arc_h.getTo()));
						}
					}
				}				
			}			
		}
		return f;
	}
	
	boolean smallerThan(TreeSet<Arc> g, TreeSet<Arc> h){
		Iterator<Arc> arc_g_it=g.iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			boolean has_larger=false;
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(arc_g.getFrom()==arc_h.getFrom()){
					if(!arc_g.getLabel()||arc_h.getLabel()){
						if(arc_g.getTo()==arc_h.getTo()){
							has_larger=true;
							break;
						}
					}
				}
			}			
			if(!has_larger){
				return false;
			}
		}
		return true;
	}

	public long getCpuTime( ) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadCpuTime( ) : 0L;
	}
	
	
	public boolean isUniversal(){
		return universal;
	}
	@Override
	public void run(){

		runTime=getCpuTime();
		universal=universal();
		runTime=getCpuTime()-runTime;
	}
	
	public long getRunTime(){
		return runTime;
	}

	private boolean universal(){
		debug(input.toString());

		ArrayList<TreeSet<Arc>> Q1=this.buildSingleCharacterGraphs();
		TreeSet<TreeSet<Arc>> Next=new TreeSet<TreeSet<Arc>>(new GraphComparator());
		TreeSet<TreeSet<Arc>> Processed=new TreeSet<TreeSet<Arc>>(new GraphComparator());
		Next.addAll(Q1);
		while(!Next.isEmpty()){
			debug("Processed:"+Processed);
			debug("Next:"+Next);

			if(stop)
				break;
			TreeSet<Arc> g=Next.first();
			Next.remove(g);
			boolean discard=false;
			ArrayList<TreeSet<Arc>> toRemove=new ArrayList<TreeSet<Arc>>();

			Iterator<TreeSet<Arc>> Processed_it=Processed.iterator();
			while(Processed_it.hasNext()){
				TreeSet<Arc> h=Processed_it.next();
				if(this.smallerThan(h, g)){
					discard=true;
					break;
				}else if(this.smallerThan(g, h)){
					toRemove.add(h);
				}else if(!lasso_finding_test(g, h, input.getInitialState().id)||!lasso_finding_test(h, g, input.getInitialState().id)){
					return false;
				}
			}
			Processed.removeAll(toRemove);
			if(!discard){
				if(!lasso_finding_test(g, g, input.getInitialState().id)){
					return false;
				}
				Processed.add(g);
				Iterator<TreeSet<Arc>> Q1_it=Q1.iterator();
				while(Q1_it.hasNext()){
					TreeSet<Arc> h=Q1_it.next();
					TreeSet<Arc> f=compose(g, h);
					Next.add(f);
					debug("f:"+f +"="+g+";"+h);
				}
			}
		}			
		return true;
	}

	public void stopIt(){
		stop=true;
	}
}
