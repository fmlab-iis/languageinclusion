/* Written by Chen Yu-Fang and Hong Chih-Duo                              */
/* Copyright (c) 2010  Academia Sinica	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package cav2010.comparator;



import java.util.Comparator;

import cav2010.automata.FAState;
import cav2010.datastructure.Pair;





public class StatePairComparator implements
		Comparator<Pair<FAState, FAState>> {

	public int compare(Pair<FAState,FAState> o1,
			Pair<FAState,FAState> o2) {
		if(o1.getLeft().getID()>o2.getLeft().getID()){
			return 1;
		}else if(o1.getLeft().getID()<o2.getLeft().getID()){ 
			return -1;
		}else if(o1.getRight().getID()>o2.getRight().getID()){ 
			return 1;
		}else if(o1.getRight().getID()<o2.getRight().getID()){ 
			return -1;
		}else{
			return 0;
		}
	}
}
