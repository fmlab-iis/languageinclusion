/* Written by Chen Yu-Fang and Hong Chih-Duo                              */
/* Copyright (c) 2010  Academia Sinica	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package cav2010.mainfiles;

import java.lang.management.*;

import java.util.Random;
import java.util.TreeMap;

import cav2010.algorithms.InclusionAnti;
import cav2010.automata.FiniteAutomaton;
import cav2010.automata.FAState;
/**
 * 
 * @author Yu-Fang Chen
 * 
 */
public class CheckingInclusion_Subsumption {
	static long timeout=0;

	/** Get CPU time in nanoseconds. */
	static public long getCpuTime( long id) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    if ( ! bean.isThreadCpuTimeSupported( ) )
	        return 0L;
	    else
	    	return bean.getThreadCpuTime(id);
	}
	
	public static void main(String[] args) {	
		if(args.length==3){			
			timeout=Integer.parseInt(args[2])*1000;
		}
		if(args.length<2){
			System.err.println("Usage: main aut1.BA aut2.BA [timeout (sec)].");
			System.err.println("The program checks if Lang(aut1) <= Lang(aut2).");
			return;
		}
		long ttime1;
		FiniteAutomaton aut1 = new FiniteAutomaton(args[0]);
		FiniteAutomaton aut2 = new FiniteAutomaton(args[1]);
		System.out.println("Aut1: # of Trans. "+aut1.trans+", # of States "+aut1.states.size()+".");
		System.out.println("Aut2: # of Trans. "+aut2.trans+", # of States "+aut2.states.size()+".");
		
		InclusionAnti inclusion=new InclusionAnti(aut1,aut2);
		inclusion.start();
		try {
			inclusion.join(timeout);
		} catch (InterruptedException e) {
		}

		if(inclusion.isAlive()){
			System.out.println("Timeout");
		}else{
			ttime1=inclusion.getRunTime();
			if(inclusion.isIncluded()){
				System.out.println("Included");
			}else{
				System.out.println("Not Included");
			}
			System.out.println("Time for the Subsumption algorithm(ms): "+ttime1/1000000+".");
		}
	}

	
	
	/**
	 *  Generate automata using Tabakov and Vardi's approach
	 * 
	 *  @param num
	 *  
	 *  @return a random finite automaton
	 *  @author Yu-Fang Chen
	 */
	public static FiniteAutomaton genRandomTV(int size, float td, float fd, int alphabetSize){
		FiniteAutomaton result = new FiniteAutomaton();
		TreeMap<Integer,FAState> st=new TreeMap<Integer,FAState>();
		
		td=td/size;
		Random r = new Random();
		
		for(int i=0;i<size;i++){
			st.put(i, result.createState());
			float rm=r.nextFloat();
			if(fd>rm)
				result.F.add(st.get(i));
		}
		result.setInitialState(st.get(0));
		result.F.add(st.get(0));
		for(int i=0;i<size;i++){
			for(int j=0;j<size;j++){
				for(int k=0;k<alphabetSize;k++){
					if(td>r.nextFloat())
						result.addTransition(st.get(i),st.get(j),("a"+k));
				}
			}
		}
		return result;
	}
}

