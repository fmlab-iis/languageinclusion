/* Written by Chen Yu-Fang and Hong Chih-Duo                              */
/* Copyright (c) 2010  Academia Sinica	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package cav2010.mainfiles;

import java.lang.management.*;

import cav2010.algorithms.UniversalityAnti;
import cav2010.automata.FiniteAutomaton;

/**
 * 
 * @author Yu-Fang Chen
 * 
 */

/** Get CPU time in nanoseconds. */
public class CheckingUniversality_Subsumption {
	static long timeout=100000;

	/** Get CPU time in nanoseconds. */
	static public long getCpuTime( long id) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    if ( ! bean.isThreadCpuTimeSupported( ) )
	        return 0L;
	    else
	    	return bean.getThreadCpuTime(id);
	}
	
	public static void main(String[] args) {	
		if(args.length==3){			
			timeout=Integer.parseInt(args[2])*1000;
		}
		if(args.length<2){
			System.err.println("Usage: main aut.BA [timeout (sec)].");
			System.err.println("The program checks if the BA aut is universal.");
			return;
		}
		long ttime1;
		FiniteAutomaton aut = new FiniteAutomaton(args[0]);
		System.out.println("# of Trans. "+aut.trans+", # of States "+aut.states.size()+".");
		
		UniversalityAnti inclusion=new UniversalityAnti(aut);
		inclusion.start();
		try {
			inclusion.join(timeout);
		} catch (InterruptedException e) {
		}

		if(inclusion.isAlive()){
			System.out.println("Timeout");
		}else{
			ttime1=inclusion.getRunTime();
			if(inclusion.isUniversal()){
				System.out.println("Universal");
			}else{
				System.out.println("Not Universal");
			}
			System.out.println("Time for the Subsumption algorithm(ms): "+ttime1/1000000+".");
		}
	}
}

