/* Written by Yu-Fang Chen, Richard Mayr, and Chih-Duo Hong               */
/* Copyright (c) 2010                  	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package algorithms;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;

import automata.FAState;
import automata.FiniteAutomaton;
import comparator.StatePairComparator;
import comparator.SuperGraphComparator;
import datastructure.Arc;
import datastructure.HashSet;
import datastructure.Metagraph;
import datastructure.MetagraphBV;
import datastructure.OneToOneTreeMap;
import datastructure.Pair;


/**
 * 
 * @author Yu-Fang Chen
 * 
 */
public class InclusionOptBV extends Thread{
	
	private int verbose =10;
	int verboseC1=1;
	int verboseMin=1;
	
	public int removedCnt;
	public boolean included=true;
	public int cntL=0;
		
	private TreeMap<String,BitSet> Tail=new TreeMap<String,BitSet>();
	private TreeMap<String,BitSet> Head=new TreeMap<String,BitSet>();
	private long runTime;
	private boolean stop=false;
	private Set<Pair<FAState,FAState>> frel, brel;
	FiniteAutomaton spec, system;
	String showSim(Set<Pair<FAState,FAState>> sim){
		String result="";
		Iterator<Pair<FAState,FAState>> sim_it=sim.iterator();
		while(sim_it.hasNext()){
			Pair<FAState,FAState> p=sim_it.next();
			if(p.getLeft().compareTo(p.getRight())!=0)
				result+=("("+p.getLeft()+","+p.getRight()+")");
		}
		return result;
	}

	void debug(String out, int v){
		if(Options.debug&&v>verbose)
		System.out.println(out);
	}
	
	
	public InclusionOptBV(FiniteAutomaton system, FiniteAutomaton spec){
		this.spec=spec;
		this.system=system;
	}
	
	/**
	 * Simplify a finite automaton by merging simulation equivalent states
	 * @param fa: a finite automaton
	 * @param Sim: some simulation rel_specation over states in the spec automaton
	 * 
	 * @return an equivalent finite automaton
	 */
	private FiniteAutomaton quotient(FiniteAutomaton fa, Set<Pair<FAState,FAState>> rel) {
		FiniteAutomaton result=new FiniteAutomaton();
		result.name=fa.name;
		TreeMap<FAState,FAState> map=new TreeMap<FAState,FAState>();
		TreeMap<FAState,FAState> reducedMap=new TreeMap<FAState,FAState>();
		
		Iterator<FAState> state_it=fa.states.iterator();
		while(state_it.hasNext()){
			FAState state=state_it.next();
			map.put(state, state);
			Iterator<FAState> state_it2=fa.states.iterator();
			while(state_it2.hasNext()){
				FAState state2=state_it2.next();
				if(rel.contains(new Pair<FAState,FAState>(state,state2)) &&
					rel.contains(new Pair<FAState,FAState>(state2,state))){
					map.put(state,state2);
				}
			}			
		}

		FAState init=result.createState();
		reducedMap.put(map.get(fa.getInitialState()), init);
		result.setInitialState(init);

		state_it=fa.states.iterator();
		while(state_it.hasNext()){
			FAState state=state_it.next();
			if(!reducedMap.containsKey(map.get(state))){
				reducedMap.put(map.get(state), result.createState());
			}
			if(fa.F.contains(state)){
				result.F.add(reducedMap.get(map.get(state)));
			}
			Iterator<String> sym_it=state.nextIt();
			while(sym_it.hasNext()){
				String sym=sym_it.next();
				Iterator<FAState> to_it=state.getNext(sym).iterator();
				while(to_it.hasNext()){
					FAState to=to_it.next();
					if(!reducedMap.containsKey(map.get(to))){
						reducedMap.put(map.get(to), result.createState());
					}
					result.addTransition(reducedMap.get(map.get(state)), reducedMap.get(map.get(to)), sym);
				}
			}
		}
		Set<Pair<FAState,FAState>> newrel=new TreeSet<Pair<FAState,FAState>>(new StatePairComparator());
		Iterator<Pair<FAState,FAState>> sim_it=rel.iterator();
		while(sim_it.hasNext()){
			Pair<FAState,FAState> sim=sim_it.next();
			FAState left,right;
			if(sim.getLeft().getowner()==fa){
				left=reducedMap.get(map.get(sim.getLeft()));
			}else{
				left=sim.getLeft();
			}
			
			if(sim.getRight().getowner()==fa){
				right=reducedMap.get(map.get(sim.getRight()));
			}else{
				right=sim.getRight();
			}
			newrel.add(new Pair<FAState,FAState>(left,right));
		}
		rel.clear();
		rel.addAll(newrel);
		
		return result;
	}	

	private boolean C1(Arc left,TreeSet<Arc> right){
		if(!Options.C1){
			return false;
		}
		if(left.getFrom()!=system.getInitialState().id){
			debug("C1("+left+","+right+")="+true,verboseC1);
			return true;
		}
		Iterator<Arc> right_it=right.iterator();
		while(right_it.hasNext()){
			Arc r=right_it.next();
			if(r.getFrom()==spec.getInitialState().id){
				if(frel.contains(new Pair<FAState,FAState>(new FAState(left.getTo(),system),new FAState(r.getTo(),spec)))){
					debug("C1("+left+","+right+")="+true,verboseC1);
					return true;
				}
			}
		}
		debug("C1("+left+","+right+")="+false,verboseC1);
		return false;
	}

	
	private boolean double_graph_test(MetagraphBV hl, MetagraphBV gr){
		if(hl.getLeft().intersects(gr.getLeft())&&!hl.getRight().intersects(gr.getRight())){
			System.out.println("System:"+hl.getLeft()+":"+gr.getLeft());
			System.out.println("Spec:"+hl.getRight()+":"+gr.getRight());
			
			return false;
		}else
			return true;
	}	
		
	private BitSet getL(TreeSet<Arc> g, int init, boolean isSpec/*spec takes upward*/){
		if(!Head.containsKey(g.toString()+":"+isSpec)){
			BitSet H=new BitSet();
			Iterator<Arc> arc_g_it=g.iterator();
			while(arc_g_it.hasNext()){
				Arc arc_g=arc_g_it.next();
				
				if((arc_g.L||isSpec/*arcs in spec do not have label*/)&&arc_g.getFrom()==init){
					H.set(arc_g.getTo());
				}
				
			}
			boolean changed=true;
			while(changed){
				changed=false;
				if(isSpec){
					Iterator<Pair<FAState,FAState>>brel_it=brel.iterator();
					while(brel_it.hasNext()){
						Pair<FAState,FAState> p=brel_it.next();
						if(p.getLeft().getowner()==spec&&p.getRight().getowner()==spec){
							if(H.get(p.getLeft().id)&&!H.get(p.getRight().id)){
								H.set(p.getRight().id);
								changed=true;
							}
						}
					}
				}else{
					Iterator<Pair<FAState,FAState>>frel_it=frel.iterator();
					while(frel_it.hasNext()){
						Pair<FAState,FAState> p=frel_it.next();
						if(p.getLeft().getowner()==system&&p.getRight().getowner()==system){
							if(H.get(p.getRight().id)&&!H.get(p.getLeft().id)){
								H.set(p.getLeft().id);
								changed=true;
							}
						}
					}
				}
			}
			Head.put(g.toString()+":"+isSpec, H);
		}
		return Head.get(g.toString()+":"+isSpec);
	}	

	private BitSet getR(TreeSet<Arc> h, boolean isSystem){
		if(!Tail.containsKey(h.toString()+":"+isSystem)){
			FiniteAutomaton fa=new FiniteAutomaton();
			OneToOneTreeMap<Integer,automata.FAState> st=new OneToOneTreeMap<Integer,automata.FAState>();
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(!st.containsKey(arc_h.getFrom()))
					st.put(arc_h.getFrom(), fa.createState());
				if(!st.containsKey(arc_h.getTo()))
					st.put(arc_h.getTo(), fa.createState());
				fa.addTransition(st.getValue(arc_h.getFrom()), st.getValue(arc_h.getTo()), arc_h.getLabel()?"1":"0");
			}
			if(!isSystem&&Options.backward){
				Iterator<Pair<FAState,FAState>>brel_it=brel.iterator();
				while(brel_it.hasNext()){
					Pair<FAState,FAState> p=brel_it.next();
					if((p.getLeft().getowner()==spec&&p.getRight().getowner()==spec)){
						if(!st.containsKey(p.getLeft().getID()))
							st.put(p.getLeft().getID(), fa.createState());
						if(!st.containsKey(p.getRight().getID()))
							st.put(p.getRight().getID(), fa.createState());
						fa.addTransition(st.getValue(p.getLeft().getID()), st.getValue(p.getRight().getID()), "0");
					}
				}
			}
			if(isSystem){
				Iterator<Pair<FAState,FAState>>frel_it=frel.iterator();
				while(frel_it.hasNext()){
					Pair<FAState,FAState> p=frel_it.next();
					if((p.getLeft().getowner()==system&&p.getRight().getowner()==system)){
						if(!st.containsKey(p.getLeft().getID()))
							st.put(p.getLeft().getID(), fa.createState());
						if(!st.containsKey(p.getRight().getID()))
							st.put(p.getRight().getID(), fa.createState());
						fa.addTransition(st.getValue(p.getRight().getID()), st.getValue(p.getLeft().getID()), "0");
					}
				}
			}
			SCC s=new SCC(fa);
			BitSet T=new BitSet();
			Iterator<FAState> s_it=s.getResult().iterator();
			while(s_it.hasNext()){
				T.set(st.getKey(s_it.next()));
			}
			TreeSet<Arc> isolatedArcs=new TreeSet<Arc>();
			isolatedArcs.addAll(h);			
			
			if(!isSystem&&Options.backward){
				Iterator<Pair<FAState,FAState>>brel_it=brel.iterator();
				while(brel_it.hasNext()){
					Pair<FAState,FAState> p=brel_it.next();
					if((p.getLeft().getowner()==spec&&p.getRight().getowner()==spec)){
						isolatedArcs.add(new Arc(p.getLeft().id,false,p.getRight().id));
					}
				}
			}
			if(isSystem){
				Iterator<Pair<FAState,FAState>>frel_it=frel.iterator();
				while(frel_it.hasNext()){
					Pair<FAState,FAState> p=frel_it.next();
					if((p.getLeft().getowner()==system&&p.getRight().getowner()==system)){
						isolatedArcs.add(new Arc(p.getRight().id,false,p.getLeft().id));
					}
				}
			}
			
			boolean changed=true;
			while(changed){
				changed=false;
				TreeSet<Arc> isolatedArcsTemp=new TreeSet<Arc>();
				Iterator<Arc> arc_it=isolatedArcs.iterator();
				while(arc_it.hasNext()){
					Arc arc=arc_it.next();
					if(!T.get(arc.getTo())){
						isolatedArcsTemp.add(arc);
					}else{
						changed=true;
						T.set(arc.getFrom());
					}
				}
				isolatedArcs=isolatedArcsTemp;
			}
			Tail.put(h.toString()+":"+isSystem, T);
		}
		return Tail.get(h.toString()+":"+isSystem);
	}	
	

	private Metagraph min(Metagraph metagraph){
		debug("before min:"+metagraph,verboseMin);
		TreeSet<Arc> left_result=new TreeSet<Arc>();
		Iterator<Arc> arc_it1 =metagraph.getLeft().iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =metagraph.getLeft().iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom()){
					if(!cur.getLabel()||other.getLabel()){
						if(cur.getTo()!=other.getTo()){
							if(frel.contains(new Pair<FAState,FAState>(new FAState(cur.getTo(),system),new FAState(other.getTo(), system )))){
								if(!frel.contains(new Pair<FAState,FAState>(new FAState(other.getTo(),system),new FAState(cur.getTo(), system )))){
									canAdd=false;
									break;
								}else if(cur.getTo()<other.getTo()){
									canAdd=false;
									break;
								}
							}
						}
					}
				}
			}			
			if(canAdd){
				left_result.add(cur);
			}
		}
		TreeSet<Arc> right_result=new TreeSet<Arc>();
		arc_it1 =metagraph.getRight().iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =metagraph.getRight().iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom()){
					if(!cur.getLabel()||other.getLabel()){
						if(cur.getTo()!=other.getTo()){
							if(frel.contains(new Pair<FAState,FAState>(new FAState(cur.getTo(),spec),new FAState(other.getTo(), spec )))){
								if(!frel.contains(new Pair<FAState,FAState>(new FAState(other.getTo(),spec),new FAState(cur.getTo(), spec )))){
									canAdd=false;
									break;
								}else if(cur.getTo()<other.getTo()){
									canAdd=false;
									break;
								}
							}
						}
					}
				}
			}			
			if(canAdd){
				right_result.add(cur);
			}
		}

		debug("after min:"+new Pair<TreeSet<Arc>, TreeSet<Arc>>(left_result,right_result),verboseMin);
		return new Metagraph(left_result,right_result, metagraph.rpstring);
	}

	private boolean contains(Set<Pair<FAState,FAState>> rel, FAState s1, FAState s2){
		return rel.contains(new Pair<FAState,FAState>(s1,s2));
	}
	private Metagraph min_plus(Metagraph metagraph){
		debug("before min:"+metagraph,verboseMin);
		TreeSet<Arc> left_result=new TreeSet<Arc>();
		Iterator<Arc> arc_it1 =metagraph.getLeft().iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =metagraph.getLeft().iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom()){
					if(!cur.getLabel()||other.getLabel()){
						if(cur.getTo()!=other.getTo()){
							if(frel.contains(new Pair<FAState,FAState>(new FAState(cur.getTo(),system),new FAState(other.getTo(), system )))){
								if(!frel.contains(new Pair<FAState,FAState>(new FAState(other.getTo(),system),new FAState(cur.getTo(), system )))){
									canAdd=false;
									break;
								}else if(cur.getTo()<other.getTo()){
									canAdd=false;
									break;
								}
							}
						}
					}
				}
			}			
			if(canAdd){
				left_result.add(cur);
			}
		}

		
		TreeSet<Arc> right_result=new TreeSet<Arc>();
		arc_it1 =metagraph.getRight().iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =metagraph.getRight().iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom() && cur.getTo()==other.getTo())
					continue;
				if(contains(brel, new FAState(cur.getFrom(),spec),new FAState(other.getFrom(), spec )) &&
				   (other.getFrom()>=cur.getFrom()||!contains(brel, new FAState(other.getFrom(),spec),new FAState(cur.getFrom(), spec )))){
					if(!cur.getLabel()||other.getLabel()){
						if(contains(frel, new FAState(cur.getTo(),spec),new FAState(other.getTo(), spec )) &&
						   (other.getTo()>=cur.getTo()||!contains(frel, new FAState(other.getTo(),spec),new FAState(cur.getTo(), spec )))){
									canAdd=false;
									break;
						}
					}
				}
			}
			if(canAdd){
				right_result.add(cur);
			}
		}
		debug("after min:"+new Pair<TreeSet<Arc>, TreeSet<Arc>>(left_result,right_result),verboseMin);
		return new Metagraph(left_result,right_result,metagraph.rpstring);
	}
	

	private ArrayList<Metagraph> buildSingleCharacterMetaGraphs(){
		TreeMap<Pair<Arc, TreeSet<Arc>>, String> SGStringmap=new TreeMap<Pair<Arc, TreeSet<Arc>>, String>(new SuperGraphComparator());
		ArrayList<Pair<Arc, TreeSet<Arc>>> supergraphs=new ArrayList<Pair<Arc, TreeSet<Arc>>>();
		Iterator<String> symbol_it=system.getAllTransitionSymbols().iterator();
		while(symbol_it.hasNext()){
			TreeSet<Arc> graph=new TreeSet<Arc>();
			String sym=symbol_it.next();
			Iterator<FAState> from_it=spec.states.iterator();
			while(from_it.hasNext()){
				FAState from=from_it.next();
				if(from.getNext(sym)!=null){
					Iterator<FAState> to_it=from.getNext(sym).iterator();
					while(to_it.hasNext()){
						FAState to=to_it.next();
						if(spec.F.contains(from)||spec.F.contains(to)){
							graph.add(new Arc(from.id,true,to.id));
						}else{
							graph.add(new Arc(from.id,false,to.id));
						}
					}
				}
			}

			from_it=system.states.iterator();
			while(from_it.hasNext()){
				FAState from=from_it.next();
				if(from.getNext(sym)!=null){
					Iterator<FAState> to_it=from.getNext(sym).iterator();
					while(to_it.hasNext()){
						FAState to=to_it.next();
						Arc left_arc;
						if(system.F.contains(from)||system.F.contains(to)){
							left_arc=new Arc(from.id,true,to.id);
						}else{
							left_arc=new Arc(from.id,false,to.id);
						}
						Pair<Arc, TreeSet<Arc>> supergraph=new Pair<Arc, TreeSet<Arc>>(left_arc,graph);
						ArrayList<Pair<Arc, TreeSet<Arc>>> toRemove=new ArrayList<Pair<Arc, TreeSet<Arc>>>();
						boolean canAdd=true;
						Iterator<Pair<Arc, TreeSet<Arc>>> old_it=supergraphs.iterator();
						while(old_it.hasNext()){
							Pair<Arc, TreeSet<Arc>> old=old_it.next();
							if(smallerThan(old, supergraph)){
								canAdd=false;
								break;
							}else if(smallerThan(supergraph, old)){
								toRemove.add(old);
							}
						}
						if(canAdd){
							if(Options.opt2)
								if(!Options.backward)
									supergraph=smin(supergraph);
								else
									supergraph=smin_plus(supergraph);

							supergraphs.add(supergraph);
							supergraphs.removeAll(toRemove);
							if(Options.debug)
								SGStringmap.put(supergraph, sym);
						}
					}
				}
			}
		}
		HashMap<String, Metagraph> MGmap=new HashMap<String, Metagraph>();
		ArrayList<Metagraph> metagraphs=new ArrayList<Metagraph>();
		Iterator<Pair<Arc, TreeSet<Arc>>> SG_it=supergraphs.iterator();
		while(SG_it.hasNext()){
			Pair<Arc, TreeSet<Arc>> SG=SG_it.next();
			if(MGmap.containsKey(SG.getRight().toString())){
				MGmap.get(SG.getRight().toString()).getLeft().add(SG.getLeft());
			}else{
				TreeSet<Arc> left=new TreeSet<Arc>();
				left.add(SG.getLeft());
				Metagraph MG=new Metagraph(left, SG.getRight());
				MGmap.put(MG.getRight().toString(), MG);
				MG.rpstring=SGStringmap.get(SG);
				metagraphs.add(MG);
			}
			
		}

			Iterator<Metagraph> Q1_it=metagraphs.iterator();
			while(Q1_it.hasNext()){
				Metagraph g=Q1_it.next();
					Iterator<Arc> left_it=g.getLeft().iterator();
					while(left_it.hasNext()){
						Arc left=left_it.next();
						boolean c1=C1(left,g.getRight());
						if(!c1){
							left.L=true;
							cntL++;
						}
					}
				}
		return metagraphs;
	}
	
	//used only by initializing metagraphs
	private Pair<Arc, TreeSet<Arc>> smin(Pair<Arc, TreeSet<Arc>> supergraph){
		debug("before min:"+supergraph,verboseMin);
		TreeSet<Arc> result=new TreeSet<Arc>();
		Iterator<Arc> arc_it1 =supergraph.getRight().iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =supergraph.getRight().iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom()){
					if(!cur.getLabel()||other.getLabel()){
						if(cur.getTo()!=other.getTo()){
							if(frel.contains(new Pair<FAState,FAState>(new FAState(cur.getTo(),spec),new FAState(other.getTo(), spec )))){
								if(!frel.contains(new Pair<FAState,FAState>(new FAState(other.getTo(),spec),new FAState(cur.getTo(), spec )))){
									canAdd=false;
									break;
								}else if(cur.getTo()<other.getTo()){
									canAdd=false;
									break;
								}
							}
						}
					}
				}
			}			
			if(canAdd){
				result.add(cur);
			}
		}
		debug("after min:"+new Pair<Arc, TreeSet<Arc>>(supergraph.getLeft(),result),verboseMin);
		return new Pair<Arc, TreeSet<Arc>>(supergraph.getLeft(),result);
	}

	//used only by initializing metagraphs
	private Pair<Arc, TreeSet<Arc>> smin_plus(Pair<Arc, TreeSet<Arc>> supergraph){
		debug("before min:"+supergraph,verboseMin);
		TreeSet<Arc> result=new TreeSet<Arc>();
		Iterator<Arc> arc_it1 =supergraph.getRight().iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =supergraph.getRight().iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom() && cur.getTo()==other.getTo())
					continue;
				if(contains(brel, new FAState(cur.getFrom(),spec),new FAState(other.getFrom(), spec )) &&
				   (other.getFrom()>=cur.getFrom()||!contains(brel, new FAState(other.getFrom(),spec),new FAState(cur.getFrom(), spec )))){
					if(!cur.getLabel()||other.getLabel()){
						if(contains(frel, new FAState(cur.getTo(),spec),new FAState(other.getTo(), spec )) &&
						   (other.getTo()>=cur.getTo()||!contains(frel, new FAState(other.getTo(),spec),new FAState(cur.getTo(), spec )))){
									canAdd=false;
									break;
						}
					}
				}
			}
			if(canAdd){
				result.add(cur);
			}
		}
		debug("after min:"+new Pair<Arc, TreeSet<Arc>>(supergraph.getLeft(),result),verboseMin);
		return new Pair<Arc, TreeSet<Arc>>(supergraph.getLeft(),result);
	}
	

	private Metagraph compose(Metagraph g, Metagraph h, TreeSet<Arc> oriL){
		TreeSet<Arc> right=new TreeSet<Arc>();
		Iterator<Arc> arc_g_it=g.getRight().iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			Iterator<Arc> arc_h_it=h.getRight().iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				boolean connected=false;
				if(Options.backward &&contains(brel, new FAState(arc_g.getTo(),spec),new FAState(arc_h.getFrom(), spec )))
					connected=true;
				else if(!Options.backward&&arc_g.getTo()==arc_h.getFrom())
					connected=true;
				if(connected){
					if(arc_g.getLabel()||arc_h.getLabel()){
						right.add(new Arc(arc_g.getFrom(),true,arc_h.getTo()));
						right.remove(new Arc(arc_g.getFrom(),false,arc_h.getTo()));
					}else{
						if(!right.contains(new Arc(arc_g.getFrom(),true,arc_h.getTo()))){
							right.add(new Arc(arc_g.getFrom(),false,arc_h.getTo()));
						}
					}
				}				
			}			
		}
				
		TreeSet<Arc> left=new TreeSet<Arc>();
		Iterator<Arc> arc_i_it=g.getLeft().iterator();
		while(arc_i_it.hasNext()){
			Arc arc_i=arc_i_it.next();
			short label=0;
			if(Options.C1){
				if(oriL.contains(arc_i)){
					label=2;
					debug("Left arc is L labeled",verboseC1);
					//L labeled (2)
				}else{
					//else N labeled (0)
					debug("Left arc is N labeled",verboseC1);

				}
			}
			Iterator<Arc> arc_h_it=h.getLeft().iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(arc_i.getTo()==arc_h.getFrom()){
					if(arc_i.getLabel()||arc_h.getLabel()){
						Arc newarc=new Arc(arc_i.getFrom(),true,arc_h.getTo());
						left.add(newarc);
						left.remove(new Arc(arc_i.getFrom(),false,arc_h.getTo()));
						newarc.R=true;
						if(Options.C1){
							if(label==2){
								if(!C1(newarc, right)){
									newarc.L=true;
									debug("Add L label to "+newarc,verboseC1);
									cntL++;
								}
							}
						}else{
							newarc.L=true;
							debug("Add L label to "+newarc,verboseC1);
							cntL++;
						}
					}else{
						if(!left.contains(new Arc(arc_i.getFrom(),true,arc_h.getTo()))){
							Arc newarc=new Arc(arc_i.getFrom(),false,arc_h.getTo());
							left.add(new Arc(arc_i.getFrom(),false,arc_h.getTo()));
							newarc.R=true;
							if(Options.C1){
								if(label==2){
									if(!C1(newarc, right)){
										newarc.L=true;
										cntL++;
									}
								}
							}else{
								newarc.L=true;
								cntL++;
							}
						}
					}
				}				
			}			
		}

		
		if(left.size()==0){
			return null;
		}else{
			return new Metagraph(left,right,g.rpstring+h.rpstring);
		}
	}
	//clean metagraph src w.r.t tgt
	//if tgt.right not smaller than src.right then does nothing
	boolean clean(Metagraph src, Metagraph tgt, short type){
		
		Iterator<Arc> arc_g_it=tgt.getRight().iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			boolean has_larger=false;
			Iterator<Arc> arc_h_it=src.getRight().iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				boolean fromOkay=false;
				if(Options.backward &&brel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getFrom(),spec),new FAState(arc_h.getFrom(), spec ))))
					fromOkay=true;
				else if(!Options.backward&&arc_g.getFrom()==arc_h.getFrom())
					fromOkay=true;
				if(fromOkay){
					if(!arc_g.getLabel()||arc_h.getLabel()){
						if(frel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getTo(),spec),new FAState(arc_h.getTo(),spec)))){
							has_larger=true;
							break;
						}
					}
				}
			}			
			if(!has_larger){
				return true;
			}
		}
		debug("Before clean"+type+" :"+src+" (w.r.t. "+tgt+")",verboseC1);
		//tgt.right smaller than src.right

		if(type!=3 && src.getRight().size()==tgt.getRight().size()){
			arc_g_it=src.getRight().iterator();
			boolean has_larger=true;
			while(arc_g_it.hasNext()){
				Arc arc_g=arc_g_it.next();
				has_larger=false;
				Iterator<Arc> arc_h_it=tgt.getRight().iterator();
				while(arc_h_it.hasNext()){
					Arc arc_h=arc_h_it.next();
					boolean fromOkay=false;
					if(Options.backward &&brel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getFrom(),spec),new FAState(arc_h.getFrom(), spec ))))
						fromOkay=true;
					else if(!Options.backward&&arc_g.getFrom()==arc_h.getFrom())
						fromOkay=true;
					if(fromOkay){
						if(!arc_g.getLabel()||arc_h.getLabel()){
							if(frel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getTo(),spec),new FAState(arc_h.getTo(),spec)))){
								has_larger=true;
								break;
							}
						}
					}
				}			
				if(!has_larger){
					break;
				}
			}
			if(has_larger){
				//src.right := tgt.right
				src.getRight().clear();
				src.getRight().addAll(tgt.getRight());
			}
		}

		boolean regain=false;
		TreeSet<Arc> left=new TreeSet<Arc>();
		arc_g_it=src.getLeft().iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			boolean has_larger=false;
			Iterator<Arc> arc_h_it=tgt.getLeft().iterator();
			Arc arc_h = null;
			while(arc_h_it.hasNext()){
				arc_h=arc_h_it.next();
				if(arc_g.getFrom()==arc_h.getFrom()){
					if(!arc_g.getLabel()||arc_h.getLabel()){
						if(frel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getTo(),system),new FAState(arc_h.getTo(),system)))){
							has_larger=true;
							break;
						}
					}
				}
			}			
			if(!has_larger){
				left.add(arc_g);
			}else if(type==2){
				if(arc_g.L){
					arc_h.L=true;
					cntL++;
					regain=true;
				}
			}
		}
		
		
		
		
//		if(src.toString().compareTo(tgt.toString())==0&& left.size()!=0)
//			System.out.println();
		src.getLeft().clear();
		src.getLeft().addAll(left);
		debug("After clean"+type+" :"+src,verboseC1);
		if(regain)
			debug("Regain L :"+tgt,verboseC1);
		return !regain;
	
	}
	
	boolean smallerThan(Pair<Arc, TreeSet<Arc>> old, Pair<Arc, TreeSet<Arc>> old2){
		Arc old_arc=old.getLeft();
		Arc old2_arc=old2.getLeft();
		if(!(old_arc.getFrom()==old2_arc.getFrom() && (old_arc.getLabel() ||!old2_arc.getLabel()) &&
				frel.contains(new Pair<FAState,FAState>(new FAState(old2_arc.getTo(),system),new FAState(old_arc.getTo(),system))))){
			return false;
		}
		
		Iterator<Arc> arc_g_it=old.getRight().iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			boolean has_larger=false;
			Iterator<Arc> arc_h_it=old2.getRight().iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				boolean fromOkay=false;
				if(Options.backward &&brel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getFrom(),spec),new FAState(arc_h.getFrom(), spec ))))
					fromOkay=true;
				else if(!Options.backward&&arc_g.getFrom()==arc_h.getFrom())
					fromOkay=true;
				if(fromOkay){
					if(!arc_g.getLabel()||arc_h.getLabel()){
						if(frel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getTo(),spec),new FAState(arc_h.getTo(),spec)))){
							has_larger=true;
							break;
						}
					}
				}
			}			
			if(!has_larger){
				return false;
			}
		}
		return true;
	}
	public void inclusionTest(){
		this.computeSim();

		debug("Aut A:",100);
		debug(system.toString(),100);
		debug("Aut B:",100);
		debug(spec.toString(),100);
		debug("FSim="+showSim(frel),100);
		if(Options.backward)
		debug("BSim="+showSim(brel),100);
		this.included=included();
	}
	public long getCpuTime( ) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadCpuTime( ) : 0L;
	}
	
	public boolean isIncluded(){
		return included;
	}
	@Override
	public void run(){

		runTime=getCpuTime();
			inclusionTest();
		runTime=getCpuTime()-runTime;
	}
	
	public long getRunTime(){
		return runTime;
	}


	void computeSim(){
		if(rd){
			spec=removeDead(spec);
			system=removeDead(system);
		}

		ArrayList<FAState> all_states=new ArrayList<FAState>();
		HashSet<String> alphabet=new HashSet<String>();
		
		all_states.addAll(spec.states);
		alphabet.addAll(spec.alphabet);

		all_states.addAll(system.states);
		alphabet.addAll(system.alphabet);
		
		
		FAState[] states=all_states.toArray(new FAState[0]);		
		boolean[] isFinal = new boolean[states.length];
		boolean[] isInit = new boolean[states.length];
		boolean[][] fsim = new boolean[states.length][states.length];
		boolean[][] bsim = new boolean[states.length][states.length];
		// sim[u][v]=true iff v in sim(u) iff v simulates u
		for(int i=0;i<states.length;i++){			
			isFinal[i] = states[i].getowner().F.contains(states[i]);
			isInit[i] =states[i].getowner().getInitialState().compareTo(states[i])==0;
		}
		for(int i=0;i<states.length;i++){
			for(int j=i;j<states.length;j++){
				fsim[i][j] = (!isFinal[i] || isFinal[j]) && states[j].fw_covers(states[i]);
				fsim[j][i] = (isFinal[i] || !isFinal[j]) && states[i].fw_covers(states[j]);
				if(Options.backward){
					bsim[i][j] = (!isInit[i] || isInit[j]) && (!isFinal[i] || isFinal[j]) && states[j].bw_covers(states[i]);
					bsim[j][i] = (isInit[i] || !isInit[j]) && (isFinal[i] || !isFinal[j]) && states[i].bw_covers(states[j]);
				}
			}
		}
		Simulation sim = new Simulation();
		frel = sim.FastFSimRelNBW(spec,system,fsim);
		if(Options.fplus){
			Set<Pair<FAState,FAState>> temp=new TreeSet<Pair<FAState,FAState>>(new StatePairComparator());
			for(int i=0;i<states.length;i++){
				for(int j=0;j<states.length;j++){
					if(isFinal[i]&&!isFinal[j]){
						Iterator<String> alphabet_it=states[i].nextIt();
						boolean covered=true;
						while(alphabet_it.hasNext()){
							String a=alphabet_it.next();
							if(states[i].getNext(a)!=null && states[j].getNext(a)==null){
								covered=false;
								break;
							}
								
							Iterator<FAState> small_it=states[i].getNext(a).iterator();
							while(small_it.hasNext()){
								FAState small=small_it.next();
								covered=false;
								if(states[j].getNext(a)!=null){
									Iterator<FAState> big_it=states[j].getNext(a).iterator();
									while(big_it.hasNext()){
										FAState big=big_it.next();
										if(frel.contains(new Pair<FAState,FAState>(small,big))){
											covered=true;
											break;
										}
									}
								}
								if(!covered)
									break;
							}
							if(!covered)
								break;
						}
						if(covered){
							temp.add(new Pair<FAState,FAState>(states[i],states[j]));
						}
					}
				}
			}
			int inc=frel.size();
			frel.addAll(temp);
			inc=frel.size()-inc;
			System.out.println("Number of increased sim pairs :"+inc);
		}
		
		
		
		if(Options.quotient){
			spec=quotient(spec, frel);
			system=quotient(system, frel);
		}
		if(Options.backward){
			all_states.clear();
			all_states.addAll(spec.states);
			all_states.addAll(system.states);
			states=all_states.toArray(new FAState[0]);		
			isFinal = new boolean[states.length];
			isInit = new boolean[states.length];
			bsim = new boolean[states.length][states.length];
			for(int i=0;i<states.length;i++){			
				isFinal[i] = states[i].getowner().F.contains(states[i]);
				isInit[i] =states[i].getowner().getInitialState().compareTo(states[i])==0;
			}
			for(int i=0;i<states.length;i++){
				for(int j=i;j<states.length;j++){
					bsim[i][j] = (!isInit[i] || isInit[j]) && (!isFinal[i] || isFinal[j]) && states[j].bw_covers(states[i]);
					bsim[j][i] = (isInit[i] || !isInit[j]) && (isFinal[i] || !isFinal[j]) && states[i].bw_covers(states[j]);
				}
			}
			brel = sim.FastBSimRelNBW(spec,system,bsim);
		}

	}	
	
	private FiniteAutomaton removeDead(FiniteAutomaton aut) {
		FiniteAutomaton result=new FiniteAutomaton();
		result.name=aut.name;
		HashSet<FAState> finalReachable=new HashSet<FAState>();

		SCC s=new SCC(aut, true);
		finalReachable.addAll(s.getResult());
		
		while(true){
			HashSet<FAState> toAdd=new HashSet<FAState>();
			Iterator<FAState> finalReachable_it=finalReachable.iterator();
			while(finalReachable_it.hasNext()){
				FAState end=finalReachable_it.next();
				toAdd.addAll(end.getPre());
			}
			toAdd.removeAll(finalReachable);
			if(toAdd.size()==0)
				break;
			finalReachable.addAll(toAdd);
		}

		HashMap<FAState, FAState> stMap=new HashMap<FAState, FAState>();
		HashSet<FAState> toProcess=new HashSet<FAState>();
		toProcess.add(aut.getInitialState());
		result.setInitialState(result.createState());
		stMap.put(aut.getInitialState(), result.getInitialState());
		if(aut.F.contains(aut.getInitialState()))
			result.F.add(result.getInitialState());

		while(true){
			HashSet<FAState> toAdd=new HashSet<FAState>();
			Iterator<FAState> toProcess_it=toProcess.iterator();
			while(toProcess_it.hasNext()){
				FAState begin=toProcess_it.next();
				Iterator<String> sym_it=begin.nextIt();
				while(sym_it.hasNext()){
					String sym=sym_it.next();
					Iterator<FAState> end_it=begin.getNext(sym).iterator();
					while(end_it.hasNext()){
						FAState end=end_it.next();
						if(finalReachable.contains(end)){
							if(!stMap.containsKey(end)){
								toAdd.add(end);
								stMap.put(end, result.createState());
								if(aut.F.contains(end))
									result.F.add(stMap.get(end));
							}
							result.addTransition(stMap.get(begin), stMap.get(end), sym);
						}
					}
				}
			}
			if(toAdd.size()==0)
				break;
			toProcess.clear();
			toProcess.addAll(toAdd);
		}
		return result;
	}

	public boolean rd=false;
	public int mggen=0;
	public boolean qr;
	public boolean layered;

	private boolean included(){
		ArrayList<Metagraph> Q1=this.buildSingleCharacterMetaGraphs();
		debug("Init:"+Q1,100);
		
		Iterator<Metagraph> Q1_it=Q1.iterator();

		while(Q1_it.hasNext()){
			Metagraph g=Q1_it.next();
			if(!double_graph_test(
					new MetagraphBV(
					getL(g.getLeft(),system.getInitialState().id, false), 
					getL(g.getRight(),spec.getInitialState().id,true)),
					new MetagraphBV(
					getR(g.getLeft(), true), getR(g.getRight(),false))
					)){
				return false;
			}
		}

		
		LinkedList<Metagraph> Next=new LinkedList<Metagraph>();
		TreeSet<Metagraph> Processed=new TreeSet<Metagraph>();
		TreeSet<MetagraphBV> ProcessedL= new TreeSet<MetagraphBV>();
		TreeSet<MetagraphBV> ProcessedR= new TreeSet<MetagraphBV>();
		Next.addAll(Q1);
		mggen+=Q1.size();
	
		while(!Next.isEmpty()&&(!Options.C1||cntL!=0)){
			if(stop)
				break;
			debug("",100);
			debug("Begin while loop",100);
			debug("Processed:"+Processed,100);
			debug("Next:"+Next,100);
			Iterator<Metagraph> Processed_it;
			Metagraph g;
			if(!Options.DFS)
				g=Next.getFirst();
			else
				g=Next.getLast();
			
			debug("Pick ["+g.rpstring+"] "+g+"from Next",100);
			MetagraphBV gl=new MetagraphBV(
					getL(g.getLeft(),system.getInitialState().id,false), 
					getL(g.getRight(),spec.getInitialState().id,true));
			MetagraphBV gr=new MetagraphBV(
					getR(g.getLeft(),true), getR(g.getRight(),false));
			debug("Add "+gl+"to ProcessedL",100);
			debug("Add "+gr+"to ProcessedR",100);
			
			
			Iterator<MetagraphBV> ProcessedL_it=ProcessedL.iterator();
			while(ProcessedL_it.hasNext()){
				MetagraphBV hl=ProcessedL_it.next();
				if(!double_graph_test(hl, gr))
					return false;
			}
			Iterator<MetagraphBV> ProcessedR_it=ProcessedR.iterator();
			while(ProcessedR_it.hasNext()){
				MetagraphBV hr=ProcessedR_it.next();
				if(!double_graph_test(gl, hr))
					return false;
			}
			
			Next.remove(g);
			Processed.add(g);
			ProcessedL.add(gl);
			ProcessedR.add(gr);

			TreeSet<Arc> ori_L=new TreeSet<Arc>();
			if(Options.C1){
				Iterator<Arc> g_it=g.getLeft().iterator();
				while(g_it.hasNext()){
					Arc left=g_it.next();
					if(left.L){
						ori_L.add(left);
						left.L=false;
						cntL--;
					}
				}
				debug("Move"+g+"from Next to Processed with L label removed",100);
			}else{
				debug("Move"+g+"from Next to Processed",100);
			}
			
			Q1_it=Q1.iterator();
			while(Q1_it.hasNext()){
				Metagraph h=Q1_it.next();
				Metagraph f=compose(g, h,ori_L);
				if(f==null)
					continue;
				if(!Options.backward)
					f=min(f);
				else
					f=min_plus(f);
//				debug("Produce f:"+f+"("+stringmap.get(f) +")=Min_s("+g+"("+stringmap.get(g) +");"+h+"("+stringmap.get(h) +"))",100);
				debug("Produce f:["+f.rpstring+"]=["+g.rpstring +"];["+h.rpstring +"]), "+f,100);

				ArrayList<Metagraph> toRemove=new ArrayList<Metagraph>();
				ArrayList<Metagraph> toAdd=new ArrayList<Metagraph>();
				Iterator<Metagraph> Next_it=Next.iterator();
				while(Next_it.hasNext()){
					Metagraph p=Next_it.next();
					
					clean(f, p, (short) 1);
					if(f.getLeft().size()==0)
						break;
					
					
					TreeSet<Arc> left=new TreeSet<Arc>();
					left.addAll(p.getLeft());
					TreeSet<Arc> right=new TreeSet<Arc>();
					right.addAll(p.getRight());
					Metagraph p_new=new Metagraph(left, right,p.rpstring); 
					clean(p_new, f, (short) 3);
					if(p_new.compareTo(p)!=0){
						toRemove.add(p);
						if(p_new.getLeft().size()>0)
							toAdd.add(p_new);
					}
				}
				if(toAdd.size()>0){
					Next.addAll(toAdd);
					toAdd.clear();
				}
				if(f.getLeft().size()==0)
					continue;
				Processed_it=Processed.iterator();
				while(Processed_it.hasNext()){
					Metagraph p=Processed_it.next();
					if(!clean(f, p,(short) 2)&&Options.C1){//p regain L somewhere
						Iterator<MetagraphBV> Proc_it=ProcessedR.iterator();
						while(Proc_it.hasNext()){
							MetagraphBV right_ext=Proc_it.next();
							MetagraphBV fl=new MetagraphBV(
									getL(f.getLeft(),system.getInitialState().id,false), 
									getL(f.getRight(),spec.getInitialState().id,true));

							if(!double_graph_test(fl, right_ext)){
								return false;
							}
						}
					}
					if(f.getLeft().size()==0)
						break;
					TreeSet<Arc> left=new TreeSet<Arc>();
					left.addAll(p.getLeft());
					TreeSet<Arc> right=new TreeSet<Arc>();
					right.addAll(p.getRight());
					Metagraph p_new=new Metagraph(left, right, p.rpstring); 
					clean(p_new, f, (short) 3);

					if(p_new.compareTo(p)!=0){
						toRemove.add(p);
						if(p_new.getLeft().size()>0)
							toAdd.add(p_new);
					}
				}
				if(f.getLeft().size()==0)
					continue;
				if(!double_graph_test(
						new MetagraphBV(
						getL(f.getLeft(),system.getInitialState().id,false), 
						getL(f.getRight(),spec.getInitialState().id,true)),
						new MetagraphBV(
						getR(f.getLeft(),true), getR(f.getRight(),false))
						)){
					return false;
				}

				Processed.removeAll(toRemove);
				Next.removeAll(toRemove);
				Processed.addAll(toAdd);
				String index="";
				mggen++;
//				Next_it=Next.iterator();
//				while(Next_it.hasNext()){
//					Pair<TreeSet<Arc>, TreeSet<Arc>> cur=Next_it.next();
//					if(cur.getRight().toString().compareToIgnoreCase(f.getRight().toString())==0){
//						merged=true;
//						cur.getLeft().addAll(f.getLeft());
//						break;
//					}
//				}
//				if(!merged)
				
				Next.add(f);
				debug("Add ["+f.rpstring+"] "+f+" to Next",100);
			}
		}
		return true;
	}			

	
	
		
	
//	private void addLabel(String type, Arc left,
//			TreeSet<Arc> right) {
//		TreeMap<TreeSet<Arc>, TreeSet<Arc>> Label=null;
//		if(type.compareTo("L")==0)
//			Label =L;
//		else
//			Label =R;
//		debug("("+left+", "+right+") adds "+type+" label");
//		
//		if(Label.get(right)==null){
//			TreeSet<Arc> empty=new TreeSet<Arc>();
//			Label.put(right, empty);
//		}
//		Label.get(right).add(left);
//	}
//	private void delLabel(TreeMap<TreeSet<Arc>, TreeSet<Arc>> Label, Arc left,
//			TreeSet<Arc> right) {
//		if(Label.get(right)==null){
//			return;
//		}
//		Label.get(right).remove(left);
//	}

	public void stopIt(){
		stop=true;
	}
}
