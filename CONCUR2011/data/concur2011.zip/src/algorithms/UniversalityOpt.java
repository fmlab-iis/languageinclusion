/* Written by Yu-Fang Chen, Richard Mayr, and Chih-Duo Hong               */
/* Copyright (c) 2010                  	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package algorithms;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import automata.FAState;
import automata.FiniteAutomaton;
import comparator.GraphComparator;
import comparator.StatePairComparator;
import datastructure.Arc;
import datastructure.OneToOneTreeMap;
import datastructure.Pair;



/**
 * 
 * @author Yu-Fang Chen
 * 
 */
public class UniversalityOpt extends Thread{
	boolean opt2=true;
	boolean debug=false;
	boolean quotient=false;
	public int removedCnt;
	public boolean universal=true;
	private TreeMap<String,TreeSet<Integer>> Tail=new TreeMap<String,TreeSet<Integer>>();
	private TreeMap<String,TreeSet<Integer>> Head=new TreeMap<String,TreeSet<Integer>>();
	private long runTime;
	private boolean stop=false;
	private Set<Pair<automata.FAState,automata.FAState>> rel;
	FiniteAutomaton input;

	void debug(String out){
		if(debug)
		System.out.println(out);
	}
	public UniversalityOpt(FiniteAutomaton input){
		this.input=input;
	}
	/**
	 * Simplify a finite automaton by merging simulation equivalent states
	 * @param fa: a finite automaton
	 * @param Sim: some simulation relation over states in the input automaton
	 * 
	 * @return an equivalent finite automaton
	 */
	private FiniteAutomaton quotient(FiniteAutomaton fa) {
		FiniteAutomaton result=new FiniteAutomaton();
		result.name=fa.name;
		TreeMap<FAState,FAState> map=new TreeMap<FAState,FAState>();
		TreeMap<FAState,FAState> reducedMap=new TreeMap<FAState,FAState>();
		
		Iterator<FAState> state_it=fa.states.iterator();
		while(state_it.hasNext()){
			FAState state=state_it.next();
			map.put(state, state);
			Iterator<FAState> state_it2=fa.states.iterator();
			while(state_it2.hasNext()){
				FAState state2=state_it2.next();
				if(rel.contains(new Pair<FAState,FAState>(state,state2)) &&
					rel.contains(new Pair<FAState,FAState>(state2,state))){
					map.put(state,state2);
				}

			}			
		}

		FAState init=result.createState();
		reducedMap.put(map.get(fa.getInitialState()), init);
		result.setInitialState(init);

		state_it=fa.states.iterator();
		while(state_it.hasNext()){
			FAState state=state_it.next();
			if(!reducedMap.containsKey(map.get(state))){
				reducedMap.put(map.get(state), result.createState());
			}
			if(fa.F.contains(state)){
				result.F.add(reducedMap.get(map.get(state)));
			}
			Iterator<String> sym_it=state.nextIt();
			while(sym_it.hasNext()){
				String sym=sym_it.next();
				Iterator<FAState> to_it=state.getNext(sym).iterator();
				while(to_it.hasNext()){
					FAState to=to_it.next();
					if(!reducedMap.containsKey(map.get(to))){
						reducedMap.put(map.get(to), result.createState());
					}
					result.addTransition(reducedMap.get(map.get(state)), reducedMap.get(map.get(to)), sym);
				}
			}
		}
		Set<Pair<FAState,FAState>> newRel=new TreeSet<Pair<FAState,FAState>>(new StatePairComparator());
		Iterator<Pair<FAState,FAState>> sim_it=rel.iterator();
		while(sim_it.hasNext()){
			Pair<FAState,FAState> sim=sim_it.next();
			newRel.add(new Pair<FAState,FAState>(reducedMap.get(map.get(sim.getLeft())),reducedMap.get(map.get(sim.getRight()))));
		}
		rel.clear();
		rel=newRel;
		
		return result;
	}	
	private boolean lasso_finding_test(TreeSet<Arc> g, TreeSet<Arc> h, int init){
		if(!Head.containsKey(g.toString())){
			TreeSet<Integer> H=new TreeSet<Integer>();
			Iterator<Arc> arc_g_it=g.iterator();
			while(arc_g_it.hasNext()){
				Arc arc_g=arc_g_it.next();
				if(arc_g.getFrom()==init){
					H.add(arc_g.getTo());
				}
			}
			Head.put(g.toString(), H);
		}
		if(!Tail.containsKey(h.toString())){
			FiniteAutomaton fa=new FiniteAutomaton();
			OneToOneTreeMap<Integer,automata.FAState> st=new OneToOneTreeMap<Integer,automata.FAState>();
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(!st.containsKey(arc_h.getFrom()))
					st.put(arc_h.getFrom(), fa.createState());
				if(!st.containsKey(arc_h.getTo()))
					st.put(arc_h.getTo(), fa.createState());
				fa.addTransition(st.getValue(arc_h.getFrom()), st.getValue(arc_h.getTo()), arc_h.getLabel()?"1":"0");
			}
			SCC s=new SCC(fa);
			TreeSet<Integer> T=new TreeSet<Integer>();
			Iterator<FAState> s_it=s.getResult().iterator();
			while(s_it.hasNext()){
				T.add(st.getKey(s_it.next()));
			}
			int TailSize=0;
			TreeSet<Arc> isolatedArcs=h;
			while(TailSize!=T.size()){
				TailSize=T.size();
				TreeSet<Arc> isolatedArcsTemp=new TreeSet<Arc>();
				Iterator<Arc> arc_it=isolatedArcs.iterator();
				while(arc_it.hasNext()){
					Arc arc=arc_it.next();
					if(!T.contains(arc.getTo())){
						isolatedArcsTemp.add(arc);
					}else{
						T.add(arc.getFrom());
					}
				}
				isolatedArcs=isolatedArcsTemp;
			}
			Tail.put(h.toString(), T);
		}
		TreeSet<Integer> intersection = new TreeSet<Integer>();
		intersection.addAll(Head.get(g.toString()));
		intersection.retainAll(Tail.get(h.toString()));
		
		if(debug){
			if(intersection.isEmpty()){
				debug("g:"+g+", Head: "+Head.get(g.toString()));
				debug("h:"+h+", Tail: "+Tail.get(h.toString()));
			}
		}
		
		return !intersection.isEmpty();
	}
	
	private TreeSet<Arc> min(TreeSet<Arc> original){
		TreeSet<Arc> result=new TreeSet<Arc>();
		Iterator<Arc> arc_it1 =original.iterator();
		while(arc_it1.hasNext()){
			Arc cur=arc_it1.next();
			boolean canAdd=true;
			Iterator<Arc> arc_it2 =original.iterator();
			while(arc_it2.hasNext()){
				Arc other=arc_it2.next();
				if(cur.getFrom()==other.getFrom()){
					if(!cur.getLabel()||other.getLabel()){
						if(cur.getTo()!=other.getTo()){
							if(rel.contains(new Pair<FAState,FAState>(new FAState(cur.getTo(),input),new FAState(other.getTo(),input))) &&
								result.contains(other)	){
								canAdd=false;
								break;
							}
						}
					}
				}
				
			}			
			if(canAdd){
				result.add(cur);
			}
		}
		return result;
	}
	
	
	private ArrayList<TreeSet<Arc>> buildSingleCharacterGraphs(){
		ArrayList<TreeSet<Arc>> graphs=new ArrayList<TreeSet<Arc>>();
		
		Iterator<String> symbol_it=input.getAllTransitionSymbols().iterator();
		while(symbol_it.hasNext()){
			TreeSet<Arc> graph=new TreeSet<Arc>();
			
			String sym=symbol_it.next();
			Iterator<FAState> from_it=input.states.iterator();
			while(from_it.hasNext()){
				FAState from=from_it.next();
				if(from.getNext(sym)!=null){
					Iterator<FAState> to_it=from.getNext(sym).iterator();
					while(to_it.hasNext()){
						FAState to=to_it.next();
						if(input.F.contains(from)||input.F.contains(to)){
							graph.add(new Arc(from.id,true,to.id));
						}else{
							graph.add(new Arc(from.id,false,to.id));
						}
					}
				}
			}

			ArrayList<TreeSet<Arc>> toRemove=new ArrayList<TreeSet<Arc>>();
			boolean canAdd=true;
			Iterator<TreeSet<Arc>> old_it=graphs.iterator();
			while(old_it.hasNext()){
				TreeSet<Arc> old=old_it.next();
				if(smallerThan(old, graph, rel)){
					canAdd=false;
					break;
				}else if(smallerThan(graph, old, rel)){
					toRemove.add(old);
				}
			}
			if(canAdd){
				if(opt2)
					graphs.add(min(graph));
				else
					graphs.add(graph);
				graphs.removeAll(toRemove);
			}
		}
		return graphs;
	}

	private TreeSet<Arc> compose(TreeSet<Arc> g, TreeSet<Arc> h){
		TreeSet<Arc> f=new TreeSet<Arc>();
		Iterator<Arc> arc_g_it=g.iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(arc_g.getTo()==arc_h.getFrom()){
					if(arc_g.getLabel()||arc_h.getLabel()){
						f.add(new Arc(arc_g.getFrom(),true,arc_h.getTo()));
						f.remove(new Arc(arc_g.getFrom(),false,arc_h.getTo()));
					}else{
						if(!f.contains(new Arc(arc_g.getFrom(),true,arc_h.getTo()))){
							f.add(new Arc(arc_g.getFrom(),false,arc_h.getTo()));
						}
					}
				}				
			}			
		}
		return f;
	}
	
	boolean smallerThan(TreeSet<Arc> g, TreeSet<Arc> h, Set<Pair<FAState,FAState>> rel){
		Iterator<Arc> arc_g_it=g.iterator();
		while(arc_g_it.hasNext()){
			Arc arc_g=arc_g_it.next();
			boolean has_larger=false;
			Iterator<Arc> arc_h_it=h.iterator();
			while(arc_h_it.hasNext()){
				Arc arc_h=arc_h_it.next();
				if(arc_g.getFrom()==arc_h.getFrom()){
					if(!arc_g.getLabel()||arc_h.getLabel()){
						if(rel.contains(new Pair<FAState,FAState>(new FAState(arc_g.getTo(),input),new FAState(arc_h.getTo(),input)))){
							has_larger=true;
							break;
						}
					}
				}
			}			
			if(!has_larger){
				return false;
			}
		}
		return true;
	}
	public void universalAS(){
		rel=computeSim();
		if(quotient)
			input=quotient(input);
		debug(input.toString());
		debug("Sim="+rel.toString());
		this.universal=universal();
		
	}
	public long getCpuTime( ) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadCpuTime( ) : 0L;
	}
	
	public boolean isUniversal(){
		return universal;
	}
	@Override
	public void run(){

		runTime=getCpuTime();
			universalAS();
		runTime=getCpuTime()-runTime;
	}
	
	public long getRunTime(){
		return runTime;
	}


	Set<Pair<FAState,FAState>> computeSim(){

		FAState[] states=input.states.toArray(new FAState[0]);		
		boolean[] isFinal = new boolean[states.length];
		boolean[][] fsim = new boolean[states.length][states.length];
		// sim[u][v]=true iff v in sim(u) iff v simulates u
		
		for(int i=0;i<states.length;i++){			
			isFinal[i] = input.F.contains(states[i]);
		}
		for(int i=0;i<states.length;i++){
			for(int j=i;j<states.length;j++){
				fsim[i][j] = (!isFinal[i] || isFinal[j]) && states[j].fw_covers(states[i]);
				fsim[j][i] = (isFinal[i] || !isFinal[j]) && states[i].fw_covers(states[j]);
			}
		}
		Simulation sim = new Simulation();
		Set<Pair<FAState,FAState>> FSim = sim.FastFSimRelNBW(input,fsim);
		
		return FSim;
	}	
	
	private boolean universal(){
		
		ArrayList<TreeSet<Arc>> Q1=this.buildSingleCharacterGraphs();
		Iterator<TreeSet<Arc>> Q1_it=Q1.iterator();
		while(Q1_it.hasNext()){
			TreeSet<Arc> g=Q1_it.next();
			if(!lasso_finding_test(g, g, input.getInitialState().id)){
				return false;
			}
		}
		TreeSet<TreeSet<Arc>> Next=new TreeSet<TreeSet<Arc>>(new GraphComparator());
		TreeSet<TreeSet<Arc>> Processed=new TreeSet<TreeSet<Arc>>(new GraphComparator());
		Next.addAll(Q1);
		while(!Next.isEmpty()){
			if(stop)
				break;
			
			TreeSet<Arc> g=Next.first();
			Iterator<TreeSet<Arc>> Processed_it=Processed.iterator();
			while(Processed_it.hasNext()){
				TreeSet<Arc> h=Processed_it.next();
				if(!lasso_finding_test(g, h, input.getInitialState().id)||!lasso_finding_test(h, g, input.getInitialState().id))
					return false;
			}
			Next.remove(g);
			Processed.add(g);
			debug("Processed:"+Processed);
			debug("Next:"+Next);
			
			Q1_it=Q1.iterator();
			while(Q1_it.hasNext()){
				ArrayList<TreeSet<Arc>> toRemove=new ArrayList<TreeSet<Arc>>();
				TreeSet<Arc> h=Q1_it.next();
				TreeSet<Arc> f=compose(g, h);
				boolean discard=false;

				debug("f:"+f +"="+g+";"+h);
				
				Processed_it=Processed.iterator();
				while(Processed_it.hasNext()){
					TreeSet<Arc> p=Processed_it.next();
					if(smallerThan(f, p, rel)){
						toRemove.add(p);
					}
					if(smallerThan(p, f, rel)){
						discard=true;
						break;
					}
				}
				if(discard)
					continue;
				Iterator<TreeSet<Arc>> Next_it=Next.iterator();
				while(Next_it.hasNext()){
					TreeSet<Arc> p=Next_it.next();
					if(smallerThan(f, p, rel)){
						toRemove.add(p);
					}
					if(smallerThan(p, f, rel)){
						discard=true;
						break;
					}
				}
				if(discard)
					continue;
				if(!lasso_finding_test(f, f, input.getInitialState().id))
					return false;
				Processed.removeAll(toRemove);
				Next.removeAll(toRemove);
				if(opt2)
					Next.add(min(f));
				else
					Next.add(f);
			}
		}			
		return true;
	}

	public void stopIt(){
		stop=true;
	}
}
