/* Written by Yu-Fang Chen, Richard Mayr, and Chih-Duo Hong               */
/* Copyright (c) 2010                  	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package datastructure;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.TreeSet;

import algorithms.Options;

public class Graph implements Comparable<Graph>, Cloneable{
	private TreeSet<Arc> data;
	private TreeMap<Integer, TreeSet<Arc>> data2;
	int size=0;
	boolean layered;
	public Graph(boolean layered){
		if(!layered)
			data=new TreeSet<Arc>();
		else{
			data2=new TreeMap<Integer, TreeSet<Arc>>();
			size=0;
		}
		
		this.layered=layered;
	}
	public Iterator<Arc> iterator(){
		if(!layered)
			return data.iterator();
		else
			return null;
	}
	public Iterator<Integer> leftStateIt(){
		return data2.keySet().iterator();
	}
	public Iterator<Arc> iterator(int x){
		if(layered){
			if(data2.containsKey(x))
				return data2.get(x).iterator();
			else 
				return new TreeSet<Arc>().iterator();
		}else
			return null;
	}
	
	public boolean addAll(Graph h){
		boolean success=true;
		if(layered){
			Iterator<Integer> leftSt_it=h.leftStateIt();
			while(leftSt_it.hasNext()){
				int leftSt=leftSt_it.next();
				if(!data2.containsKey(leftSt)){
					data2.put(leftSt, new TreeSet<Arc>());
				}
				int preSize=data2.get(leftSt).size();
				success=success&&data2.get(leftSt).addAll(h.data2.get(leftSt));
				size+=(data2.get(leftSt).size()-preSize);
			}
		}else{
			success=data.addAll(h.data);
		}
		return success;
	}
	public void add(Arc a){
		if(layered){
			if(!data2.containsKey(a.getFrom())){
				data2.put(a.getFrom(), new TreeSet<Arc>());
			}
			if(!data2.get(a.getFrom()).contains(a)){
				data2.get(a.getFrom()).add(a);
				size++;
			}
		}else{
			data.add(a);
		}
	}
	public boolean contains(Arc a){
		if(layered){
			if(data2.containsKey(a.getFrom())){
				return data2.get(a.getFrom()).contains(a);
			}else
				return false;
		}else
			return data.contains(a);
	}
	public void remove(Arc a) {
		if(layered){
			if(data2.containsKey(a.getFrom())){
				if(data2.get(a.getFrom()).contains(a)){
					data2.get(a.getFrom()).remove(a);
					size--;
					if(data2.get(a.getFrom()).size()==0)
						data2.remove(a.getFrom());
				}
			}
		}else{
			data.remove(a);
		}
	}
	
	public int size() {
		if(layered){
			return size;
		}else{
			return data.size();
		}
	}
	public void clear() {
		if(layered){
			data2.clear();
			size=0;
		}else
			data.clear();
	}
	public String toString(){
		if(!Options.debug)
			return "";
		else if(layered)
			return data2.toString();
		else
			return data.toString();
	}
	
	public Graph clone(){
		Graph dup=new Graph(layered);
		if(layered){
			Iterator<Integer> curInt_it=data2.keySet().iterator();
			while(curInt_it.hasNext()){
				int curInt=curInt_it.next();
				Iterator<Arc> cur_it=data2.get(curInt).iterator();
				while(cur_it.hasNext()){
					Arc arc=cur_it.next();
					Arc dupArc=new Arc(arc.getFrom(),arc.getLabel(),arc.getTo());
					dupArc.L=arc.L;
					dup.add(dupArc);
				}
			}
		}else{
			Iterator<Arc> cur_it=data.iterator();
			while(cur_it.hasNext()){
				Arc arc=cur_it.next();
				Arc dupArc=new Arc(arc.getFrom(),arc.getLabel(),arc.getTo());
				dupArc.L=arc.L;
				dup.add(dupArc);
			}
		}
		return dup;
	}
	
	public int compareTo(Graph arg0) {
		Graph oth=(Graph) arg0;
		if(layered){
			if(!oth.layered){
				return -1;
			}else if(size!=oth.size){
				return size-oth.size;
			}else if(data2.size()!=oth.data2.size()){
				return data2.size()-oth.data2.size();
			}else{
				Iterator<Integer> curInt_it=data2.keySet().iterator();
				Iterator<Integer> othInt_it=oth.data2.keySet().iterator();
				while(curInt_it.hasNext()){
					int curInt=curInt_it.next();
					int othInt=othInt_it.next();
					if(curInt!=othInt){
						return curInt-othInt;
					}else{
						if(data2.get(curInt).size()!=oth.data2.get(curInt).size())
							return data2.get(curInt).size()-oth.data2.get(curInt).size();
						Iterator<Arc> cur_it=data2.get(curInt).iterator();
						Iterator<Arc> oth_it=oth.data2.get(curInt).iterator();
						while(cur_it.hasNext()){
							Arc curArc=cur_it.next();
							Arc othArc=oth_it.next();
							int larger=curArc.compareTo(othArc);
							if(larger!=0){
								return larger;
							}
						}
					}
				}
				return 0;
			}
		}else{
			if(oth.layered)
				return 1;
			else if(data.size()!=oth.data.size()){
				return data.size()-oth.data.size();
			}else{
				Iterator<Arc> cur_it=data.iterator();
				Iterator<Arc> oth_it=oth.data.iterator();
				while(cur_it.hasNext()){
					Arc curArc=cur_it.next();
					Arc othArc=oth_it.next();
					int larger=curArc.compareTo(othArc);
					if(larger!=0){
						return larger;
					}
				}
				return 0;
			}
		}
	}
}
