/* Written by Yu-Fang Chen, Richard Mayr, and Chih-Duo Hong               */
/* Copyright (c) 2010                  	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package mainfiles;

import java.lang.management.*;

import java.util.Random;
import java.util.TreeMap;

import automata.FAState;
import automata.FiniteAutomaton;

import algorithms.InclusionAnti;
import algorithms.InclusionOpt;
import algorithms.InclusionOpt2;
import algorithms.InclusionOpt3;
import algorithms.InclusionOpt4;
import algorithms.InclusionOpt5;
import algorithms.InclusionOptBV;
import algorithms.InclusionOptBVLayered;
import algorithms.Options;
/**
 * 
 * @author Yu-Fang Chen
 * 
 */
public class CheckingInclusion_SimulationSubsumption {
	static long timeout=0;
	static boolean timeout_set=false;
	/** Get CPU time in nanoseconds. */
	static public long getCpuTime( long id) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    if ( ! bean.isThreadCpuTimeSupported( ) )
	        return 0L;
	    else
	    	return bean.getThreadCpuTime(id);
	}
	
	public static void main(String[] args) {
		boolean cav2010=false;
		for(int i=0;i<args.length;i++){
			if(args[i].compareTo("-h")==0){
				System.out.println("Usage: main aut1.BA aut2.BA [-h -q -qr -c -l -rd -DFS -SFS -fplus -b -d -v]");
				System.out.println("-h: show this page");
				System.out.println("-q: do quotienting w.r.t. forward simulation");
				System.out.println("-qr: do fw/bw quotienting repeatedly until a fixed point is reached");
				System.out.println("-c: use forward simulation between A and B");
				System.out.println("-l: use layered arc sets");
				System.out.println("-rd: remove dead states");
				System.out.println("-DFS: use DFS searching strategy (default: BFS strategy)");
				System.out.println("-SFS: use smallest-first searching strategy (default: BFS strategy)");
				System.out.println("-fplus: use one-step-further forward simulation");
				System.out.println("-b: use backward simulation");
				System.out.println("-d: debug mode");
				System.out.println("-v: verbose mode");
				System.out.println("For best performance we recommend options -q -b -rd -fplus -SFS -qr -c -l");
				System.exit(0);
			}
		}

		if(args.length<2){
			System.out.println("Usage: main aut1.BA aut2.BA [-h -q -qr -c -l -rd -DFS -SFS -fplus -b -d -v]");
			System.out.println("-h: show this page");
			System.out.println("-q: do quotienting w.r.t. forward simulation");
			System.out.println("-qr: do fw/bw quotienting repeatedly until a fixed point is reached");
			System.out.println("-c: use forward simulation between A and B");
			System.out.println("-l: use layered arc sets");
			System.out.println("-rd: remove dead states");
			System.out.println("-DFS: use DFS searching strategy (default: BFS strategy)");
			System.out.println("-SFS: use smallest-first searching strategy (default: BFS strategy)");
			System.out.println("-fplus: use one-step-further forward simulation");
			System.out.println("-b: use backward simulation");
			System.out.println("-d: debug mode");
			System.out.println("-v: verbose mode");
			System.out.println("For best performance we recommend options -q -b -rd -fplus -SFS -qr -c -l");
			return;
		}
		long ttime1;
		FiniteAutomaton aut1 = new FiniteAutomaton(args[0]);
		aut1.name="A";
		FiniteAutomaton aut2 = new FiniteAutomaton(args[1]);
		aut2.name="B";
		System.out.println("Ver. 1.10, Test if L(A) <= L(B)");

		Options.quotient=false;
		Options.C1=false;
		Options.C1x=false;
		Options.C2=false;
		Options.backward=false;
		Options.opt2=true;
		Options.debug=false;
		Options.fplus=false;
		Options.rd=false;
		Options.DFS=false;
		Options.qr=false;
		Options.layered=false;
		Options.verbose=false;
		
		for(int i=2;i<args.length;i++){
			if(args[i].compareTo("-qr")==0){
				Options.qr=true;
			}
			if(args[i].compareTo("-l")==0){
				Options.layered=true;
			}
			if(args[i].compareTo("-q")==0){
				Options.quotient=true;
			}
			if(args[i].compareTo("-rd")==0){
				Options.rd=true;
			}
			if(args[i].compareTo("-c")==0){
				Options.C1=true;
			}
			if(args[i].compareTo("-DFS")==0){
				Options.DFS=true;
			}
			if(args[i].compareTo("-SFS")==0){
				Options.SFS=true;
			}
			if(args[i].compareTo("-c2")==0){
				Options.C2=true;
			}
			if(args[i].compareTo("-b")==0){
				Options.backward=true;
			}
			if(args[i].compareTo("-fplus")==0){
				Options.fplus=true;
			}
			if(args[i].compareTo("-d")==0){
				Options.debug=true;
			}
			if(args[i].compareTo("-v")==0){
				Options.verbose=true;
			}
			if(args[i].compareTo("-cav2010")==0){
				cav2010=true;
			}
		}

		System.out.println("Aut A: # of Trans. "+aut1.trans+", # of States "+aut1.states.size()+".");
		System.out.println("Aut B: # of Trans. "+aut2.trans+", # of States "+aut2.states.size()+".");
		if(!cav2010){
			InclusionOptBVLayered inclusion=new InclusionOptBVLayered(aut1,aut2);
			inclusion.run();
			ttime1=inclusion.getRunTime();
			if(inclusion.isIncluded()){
				System.out.println("Included");
			}else{
				System.out.println("Not Included");
			}
			System.out.println("Metagraphs added to the Next set "+inclusion.mggen);
			System.out.println("Time for the Simulation Subsumption algorithm(ms): "+ttime1/1000000+".");
		}else{
			InclusionOpt inclusion=new InclusionOpt(aut1,aut2);
			inclusion.run();
			ttime1=inclusion.getRunTime();
			if(inclusion.isIncluded()){
				System.out.println("Included");
			}else{
				System.out.println("Not Included");
			}
			System.out.println("Time for the Simulation Subsumption algorithm(ms): "+ttime1/1000000+".");
		}
		
	}
}
