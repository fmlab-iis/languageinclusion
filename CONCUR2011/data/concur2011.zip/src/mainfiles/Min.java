/* Written by Yu-Fang Chen, Richard Mayr, and Chih-Duo Hong               */
/* Copyright (c) 2010                  	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package mainfiles;

import java.lang.management.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import automata.FAState;
import automata.FiniteAutomaton;
import comparator.StatePairComparator;
import datastructure.HashSet;
import datastructure.Pair;

import algorithms.InclusionOpt;
import algorithms.InclusionOpt2;
import algorithms.Simulation;
/**
 * 
 * @author Yu-Fang Chen
 * 
 */
public class Min {
	private static Set<Pair<FAState,FAState>> rel;
	public static void main(String[] args) {	
		Random r = new Random();
		if(args.length<2){
			System.out.println("Usage: Min b/f filename");
			System.out.println("Output: filename_m.BA");
			System.out.println("Example: Min b test");
		}else{
			String method=args[0];
			String name=args[1];
			FiniteAutomaton ba=new FiniteAutomaton(name+".ba");
			FAState[] states=ba.states.toArray(new FAState[0]);		
			boolean[] isFinal = new boolean[states.length];
			boolean[] isInit = new boolean[states.length];
			boolean[][] sim = new boolean[states.length][states.length];
			for(int i=0;i<states.length;i++){			
				isFinal[i] = states[i].getowner().F.contains(states[i]);
				isInit[i] =states[i].getowner().getInitialState().compareTo(states[i])==0;
			}
			if(method.compareToIgnoreCase("F")==0){
				for(int i=0;i<states.length;i++){
					for(int j=i;j<states.length;j++){
						sim[i][j] = (!isFinal[i] || isFinal[j]) && states[j].fw_covers(states[i]);
						sim[j][i] = (isFinal[i] || !isFinal[j]) && states[i].fw_covers(states[j]);
					}
				}
			
			}else{
				for(int i=0;i<states.length;i++){
					for(int j=i;j<states.length;j++){
						sim[i][j] = (!isInit[i] || isInit[j]) && (!isFinal[i] || isFinal[j]) && states[j].bw_covers(states[i]);
						sim[j][i] = (isInit[i] || !isInit[j]) && (isFinal[i] || !isFinal[j]) && states[i].bw_covers(states[j]);
					}
				}
			}
			Simulation simu = new Simulation();
			if(method.compareToIgnoreCase("F")==0){
				rel = simu.FastFSimRelNBW(ba,sim);
			}else{
				rel = simu.FastBSimRelNBW(ba,null,sim);
			}
			ba=quotient(ba, rel);
			ba.saveAutomaton(name+"_m.ba");			
		}
	}
	
	
		/**
		 * Simplify a finite automaton by merging simulation equivalent states
		 * @param fa: a finite automaton
		 * @param Sim: some simulation rel_specation over states in the spec automaton
		 * 
		 * @return an equivalent finite automaton
		 */
		private static FiniteAutomaton quotient(FiniteAutomaton fa, Set<Pair<FAState,FAState>> rel) {
			FiniteAutomaton result=new FiniteAutomaton();
			result.name=fa.name;
			TreeMap<FAState,FAState> map=new TreeMap<FAState,FAState>();
			TreeMap<FAState,FAState> reducedMap=new TreeMap<FAState,FAState>();
			
			Iterator<FAState> state_it=fa.states.iterator();
			while(state_it.hasNext()){
				FAState state=state_it.next();
				map.put(state, state);
				Iterator<FAState> state_it2=fa.states.iterator();
				while(state_it2.hasNext()){
					FAState state2=state_it2.next();
					if(rel.contains(new Pair<FAState,FAState>(state,state2)) &&
						rel.contains(new Pair<FAState,FAState>(state2,state))){
						map.put(state,state2);
					}
				}			
			}

			FAState init=result.createState();
			reducedMap.put(map.get(fa.getInitialState()), init);
			result.setInitialState(init);

			state_it=fa.states.iterator();
			while(state_it.hasNext()){
				FAState state=state_it.next();
				if(!reducedMap.containsKey(map.get(state))){
					reducedMap.put(map.get(state), result.createState());
				}
				if(fa.F.contains(state)){
					result.F.add(reducedMap.get(map.get(state)));
				}
				Iterator<String> sym_it=state.nextIt();
				while(sym_it.hasNext()){
					String sym=sym_it.next();
					Iterator<FAState> to_it=state.getNext(sym).iterator();
					while(to_it.hasNext()){
						FAState to=to_it.next();
						if(!reducedMap.containsKey(map.get(to))){
							reducedMap.put(map.get(to), result.createState());
						}
						result.addTransition(reducedMap.get(map.get(state)), reducedMap.get(map.get(to)), sym);
					}
				}
			}
			Set<Pair<FAState,FAState>> newrel=new TreeSet<Pair<FAState,FAState>>(new StatePairComparator());
			Iterator<Pair<FAState,FAState>> sim_it=rel.iterator();
			while(sim_it.hasNext()){
				Pair<FAState,FAState> sim=sim_it.next();
				FAState left,right;
				if(sim.getLeft().getowner()==fa){
					left=reducedMap.get(map.get(sim.getLeft()));
				}else{
					left=sim.getLeft();
				}
				
				if(sim.getRight().getowner()==fa){
					right=reducedMap.get(map.get(sim.getRight()));
				}else{
					right=sim.getRight();
				}
				newrel.add(new Pair<FAState,FAState>(left,right));
			}
			rel.clear();
			rel.addAll(newrel);
			
			return result;
		}	

}
