The files 
local_Scale_res_#td_#ad_12.txt
contain the results of the scalability test
and random automata with given td, ad, and sizes
of n=50, 100, 150, ..., 1000.

Different colums contain the results for different methods.
RD: just remove dead states,
Classic: remove dead states and quotient w.r.t. delayed simulation.
Light-12,
Heavy-12.

First, it lists the average sizes of the minimized automata,
in percent of the original size.
Then it lists the average and median computation times for each method.
(Note that average and median times are very similar here).

The files plotcode.txt computes and plots the curve fitting
with the help of the free computer algebra tool "Maxima".
