This bundle contains several tools.

1. RABIT version 2.0: 
A tool for checking language inclusion of Buchi automata.

2. Reduce version 1.0:
A tool for minimizing Buchi automata.

3. Vardi:
An auxiliary tool for creating random automata according to the 
Tabakov-Vardi model.

For convenience, .jar files of the tools and some example automata are provided.
Each tool contains a help text on its use; just invoke them without arguments
for help.
The .ba file format of the files containing Buchi automata is 
documented at http://www.languageinclusion.org/doku.php?id=tools
This format is also supported by the GOAL tool 
(http://goal.im.ntu.edu.tw/wiki/doku.php?id=start)

The source code (Java 6) is contained in the subdirectories
automata, comparator, datastructure, algorithms and mainfiles.
The code for the tools is located in the directory `mainfiles'.
(Set the classpath to the patent directory of these to compile). 

The subdirectory `Examples' contains more example automata.
The subdirectory `Experiments' contains experimental results.

The underlying theory is described in the paper
"Advanced Automata Minimization"
by R. Mayr and L. Clemente, to appear in the POPL 2013 conference.
A longer technical report is available at 
http://homepages.inf.ed.ac.uk/rmayr/publications.html
See also www.languageinclusion.org

Examples of how to use the tools:

java -jar Reduce.jar fischer.3.2.c.ba 10
(This minimizes the automaton fischer.3.2.c.ba with a method using lookahead 10.)

java -jar RABIT.jar fischer.3.c.ba fischer.3.2.c.ba -fast
(This checks language inclusion of the automata 
fischer.3.c.ba and fischer.3.2.c.ba by using the fastest method
available in the RABIT tool.)

java -jar Vardi.jar 300 1.8 0.5 test
java -jar Reduce.jar test.ba 10
(This creates a Tabakov-Vardi random automaton test.ba with 300 states, 
alphabet size 2, transition density 1.8 and acceptance density 0.5.
This is then minimized with a method using lookahead 10.)


Note on the Reduce tool:

This current version implements the Light-k and Heavy-k methods
described in the paper, plus some additional methods.
To get Light-k: Invoke with option -light
To get Heavy-k: Invoke with option -nojump
To get the most recent: Invoke without options
All experiments described in the paper referring to
be Heavy-k method used the option -nojump.

Attribution: 

This code of the RABIT 2.0 and Reduce 1.0 tools 
is developed and maintained by Richard Mayr 
and licensed under GPLv2.
It re-uses some parts of the code of the old version
1.1 of the RABIT-tool, developed by Y.F. Chen, C. Hong,
and R. Mayr.
