This bundle contains several tools.

1. RABIT version 2.1: 
A tool for checking language inclusion of nondeterministic Buchi automata
and nondeterministic finite-word automata (NFA).

2. Reduce version 1.1:
A tool for minimizing nondeterministic Buchi automata and 
nondeterministic finite-word automata (NFA).

3. TV:
An auxiliary tool for creating random automata according to the 
Tabakov-Vardi model.

4. toTimbuk:
This tool converts the .ba word-automata format into (a fragment of) the
.timbuk tree-automata format. It does not exactly preserve the language,
because a new start symbol is introduced. However, language
inclusion/equivalence between two so converted NFAs is preserved.

For convenience, .jar files of the tools and some example automata are provided.
Each tool contains a help text on its use; just invoke them without arguments
for help.
The .ba file format of the files containing Buchi automata is 
documented at http://www.languageinclusion.org/doku.php?id=tools
This format is also supported by the GOAL tool 
(http://goal.im.ntu.edu.tw/wiki/doku.php?id=start)

The source code (Java 6) is contained in the subdirectories
automata, comparator, datastructure, algorithms and mainfiles.
The code for the tools is located in the directory `mainfiles'.
(Set the classpath to the patent directory of these to compile). 

The subdirectory `Examples' contains more example automata.
The subdirectory `Experiments' contains experimental results.

The underlying theory is described in the paper
"Advanced Automata Minimization"
by R. Mayr and L. Clemente, to appear in the POPL 2013 conference.
A longer technical report is available at 
http://homepages.inf.ed.ac.uk/rmayr/publications.html
http://arxiv.org/abs/1210.6624
See also www.languageinclusion.org

Examples of how to use the tools:

java -jar Reduce.jar fischer.3.2.c.ba 10
(This minimizes the Buchi automaton fischer.3.2.c.ba with a method using
lookahead 10.)

java -jar Reduce.jar fischer.3.2.c.ba 10 -finite
(This minimizes the NFA fischer.3.2.c.ba with a method using
lookahead 10.)

java -jar RABIT.jar fischer.3.c.ba fischer.3.2.c.ba -fast
(This checks language inclusion of the Buchi automata 
fischer.3.c.ba and fischer.3.2.c.ba by using the fastest method
available in the RABIT tool.)

java -jar RABIT.jar finite_reduced_10_fischer.3.2.c.ba fischer.3.2.c.ba -fast -finite
(This checks language inclusion of the NFAs
finite_reduced_10_fischer.3.2.c.ba (created by the Reduce-minimization command
above) and fischer.3.2.c.ba, by using the fastest method for NFA inclusion
available in the RABIT tool.)

java -jar TV.jar 300 1.8 0.5 test
java -jar Reduce.jar test.ba 10
(This creates a Tabakov-Vardi random automaton test.ba with 300 states, 
alphabet size 2, transition density 1.8 and acceptance density 0.5.
This is then minimized (as a Buchi automaton) with a method using lookahead 10.)


Note on the Reduce tool:

This current version 1.1. of Reduce implements the Light-k and Heavy-k methods
described in the paper, plus some additional methods.
To get Light-k: Invoke with option -light
To get Heavy-k: Invoke with option -nojump
To get the (better) default: Invoke without options.
Invoking with option -pebble uses a method with 2-pebble
simulation in some limited circumstances. 
Theoretically this minimizes better, but in practice it is slow
and mostly not worth the effort.
The options -light, -nojump, -pebble are mutually exclusive.

By default, Reduce minimizes Buchi automata. 
One can switch the semantics to NFA by using the additional option -finite



All experiments described in the POPL 2013 paper referring to
the Heavy-k method used the option -nojump.

Attribution: 

This code of the RABIT 2.1 and Reduce 1.1 tools 
is developed and maintained by Richard Mayr 
and licensed under GPLv2.
It re-uses some parts of the code of the old version
1.1 of the RABIT-tool, developed by Y.F. Chen, C. Hong,
and R. Mayr.
