/* Written by Yu-Fang Chen, Richard Mayr, and Chih-Duo Hong               */
/* Copyright (c) 2010-2012                  	                                  */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/

package mainfiles;

import java.lang.management.*;

import java.util.Random;
import java.util.TreeMap;
import java.util.Iterator;

/*
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
*/

import automata.FAState;
import automata.FiniteAutomaton;
import algorithms.Minimization;
import algorithms.Simulation;

/**
 * 
 * @author Richard Mayr, Yu-Fang Chen
 * 
 */
public class Reduce {
    static long timeout=0;
    static boolean timeout_set=false;

	/** Get CPU time in nanoseconds. */

	static public long getCpuTime( long id) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    if ( ! bean.isThreadCpuTimeSupported( ) )
	        return 0L;
	    else
	    	return bean.getThreadCpuTime(id);
	}

	  static public long getCpuTime() {
	      return (1000000*System.currentTimeMillis());
	      /*
		ThreadMXBean bean = ManagementFactory.getThreadMXBean();
		return bean.isCurrentThreadCpuTimeSupported() ? bean
				.getCurrentThreadCpuTime() : 0L;
	      */
	}
	



    public static void main(String[] args) {
	boolean light=false;
	boolean nojump=false;
	boolean pebble=false;
	boolean finite=false;

		System.out.println("RABIT-Reduce (v. 1.1): A tool for minimizing Buchi automata and finite automata.");
		for(int i=0;i<args.length;i++){
			if(args[i].compareTo("-h")==0){
				System.out.println("Usage: java -jar Reduce.jar aut.ba  n [-light] [-nojump] [-pebble] [-finite]");
				System.out.println("-h: Show this page");
				System.out.println("aut.ba is a Buchi automaton (or finite automaton, resp.)");
				System.out.println("n >= 1 is a natural number to set the strength of the minimization. On average, larger n takes longer to compute and yields smaller automata. We recommend to use 12.");
				System.out.println("Options light/nojump/pebble are mutually exclusive, but each can be combined with option -finite.");
				System.out.println("No option: The default. Best balance between minimization and computation time, on average.");
				System.out.println("-light: Only remove dead states and quotient with lookahead delayed simulation. For comparison only.");
				System.out.println("-nojump: Like the default, except that it does not use jumping simulation.");
				System.out.println("-pebble: Default, plus use of 2 pebbles in some cases. Very slow. On average it is better to use the default with higher lookahead instead.");
				System.out.println("-finite: Minimize finite automata, not Buchi automata.");
				System.out.println("Output: Minimized automaton.");
				System.exit(0);
			}
			if(args[i].compareTo("-light")==0){
			    light=true;
			}
			else if(args[i].compareTo("-nojump")==0){
			    nojump=true;
			}
			else if(args[i].compareTo("-pebble")==0){
			    pebble=true;
			}
			else if(args[i].compareTo("-finite")==0){
			    finite=true;
			}
		}

		if(args.length == 0){
		    System.out.println("Invoke with option -h for help.");
				System.exit(0);
		}
		    long ttime1, ttime2;
		FiniteAutomaton aut = new FiniteAutomaton(args[0]);
		aut.name=args[0];
		int la = Integer.parseInt(args[1]);

		System.out.println("Input automaton: # of Trans. "+aut.trans+", # of States "+aut.states.size()+".");
		ttime1=getCpuTime();
		Minimization x = new Minimization();
		FiniteAutomaton aut2;
		
		if(!finite){
		    // Minimize Buchi aut.
		    if(light) aut2 = x.LightweightMinimize_Buchi(aut, la);
		    else if(nojump) aut2 = x.experimental_noj_Minimize_Buchi(aut, la);
		    else if(pebble) aut2 = x.addpebble_Minimize_Buchi(aut, la);
		    else aut2 = x.Minimize_Buchi(aut, la);
		}
		else{
		    // Minimize finite aut.
		    if(light) aut2 = x.LightweightMinimize_Finite(aut, la);
		    else if(nojump) aut2 = x.Minimize_Finite(aut, la, true, false, false);
		    else if(pebble) aut2 = x.Minimize_Finite(aut, la, true, true, true);
		    else aut2 = x.Minimize_Finite(aut, la, true, true, false);
		}
		ttime2=getCpuTime();    

		String newname;
		if(light) newname="light_reduced_"+la+"_"+aut.name;
		else if(nojump) newname="nojump_reduced_"+la+"_"+aut.name;
		else if(pebble) newname="pebble_reduced_"+la+"_"+aut.name;
		else newname="reduced_"+la+"_"+aut.name;
		if(finite) newname="finite_"+newname;

		aut2.saveAutomaton(newname);

		System.out.println("Reduced automaton: # of Trans. "+aut2.trans+", # of States "+aut2.states.size()+".");
		System.out.println("Saved as "+newname);
		System.out.println("Time for the minimization algorithm(ms): "+((ttime2-ttime1)/1000000)+".");
		return;
    }
}
