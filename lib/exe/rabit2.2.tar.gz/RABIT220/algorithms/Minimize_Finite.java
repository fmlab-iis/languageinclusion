    // Author: Richard Mayr.
    // Return a new minimized finite automaton (not Buchi aut.!), 
    // according to the use of lookahead i and the best known techniques.
    // The parameter automaton is not modified.

   public FiniteAutomaton Minimize_Finite(FiniteAutomaton system2, int i){
	    FiniteAutomaton system=finite_removeDead(system2);
	    Simulation sim2 = new Simulation();
	    Set<Pair<FAState, FAState>> frel, brel, bla_frel, bla_brel;
	    // These count the number of removed transitions, or reduced states.
	        int r1=0;
		int r5=0;
		int oldsizes=0;

		// The outer loop uses expensive lookahead pruning and quotienting at the end, if options given.
		do{
		    // Do this until nothing changes anymore. 
		    do
		    {
			system = finite_removeDead(system);

		        r5 = system.states.size()+system.trans;
			system = finite_single_fwbw_reduce(system);
			r5 = r5 - (system.states.size()+system.trans); // r5 is 0 iff nothing changed		

			brel = sim2.BackwardSimRelNBW(system,null);
			frel = sim2.ForwardSimRelNBW(system, null);
			// Remove transitions in A that are subsumed by other transitions in A
			r1 = removed_trans_extra(system, system, frel, brel);
			// Now remove dead states again
			system = finite_removeDead(system);
		    } while(r1+r5 > 0);

		    oldsizes=system.states.size()+system.trans;

		    // Repeated bw/fw quotienting w.r.t. direct bla sim.
		    system = finite_bla_single_fwbw_reduce(system, i);
		    // system is now also fully bw quotiented.

		    // Prune transitions w.r.t. bla_frel, brel
		    brel = sim2.BackwardSimRelNBW(system,null);
		    bla_frel=sim2.BLASimRelNBW(system, null, i);
		    removed_trans_extra(system, system, bla_frel, brel);
		    system=finite_removeDead(system);
		    
		    // Prune transitions w.r.t. frel, bla_brel
		    // First need to make sure it is fully fw quotiented
		    frel=sim2.ForwardSimRelNBW(system, null);
		    system=quotient(system, frel);
		    // Now compute sims for pruning
		    bla_brel = sim2.BLABSimRelNBW(system, null, i);
		    frel=sim2.ForwardSimRelNBW(system, null);
		    removed_trans_extra(system, system, frel, bla_brel);
		    system=finite_removeDead(system);

		    // Quotienting w.r.t. bla forward simulation 
		    bla_frel=sim2.BLASimRelNBW(system, null, i);
		    system=quotient(system, bla_frel);

		    } while(system.states.size()+system.trans < oldsizes);


		return system;
	    }


	private FiniteAutomaton finite_single_fwbw_reduce(FiniteAutomaton system){
	    Simulation sim2 = new Simulation();
	    Set<Pair<FAState, FAState>> frel,brel;
	    int oldsys=0;
	    int oldsys_trans=0;
	    do{
	     oldsys=system.states.size();
	     oldsys_trans = system.trans;

	     frel = sim2.ForwardSimRelNBW(system,null);
	     prune_fw(system,frel);
             system=quotient(system, frel);
	     system=finite_removeDead(system);
	
   	     brel = sim2.BackwardSimRelNBW(system,null);
             prune_bw(system,brel);
             system=quotient(system, brel);
	     system=finite_removeDead(system);
	     } while(oldsys > system.states.size() || oldsys_trans > system.trans);

	    return(system);
	}	


    private FiniteAutomaton finite_bla_single_fwbw_reduce(FiniteAutomaton system, int i){
	    Simulation sim2 = new Simulation();
	    Set<Pair<FAState, FAState>> bla_frel, bla_brel;
	    int oldsys=0;
	    int oldsys_trans=0;
	    do{
	    oldsys=system.states.size();
	    oldsys_trans = system.trans;

	    bla_frel=sim2.BLASimRelNBW(system, null, i);
	    prune_fw(system, bla_frel);
            system=quotient(system, bla_frel);
	    system=finite_removeDead(system);
	
   	    bla_brel = sim2.BLABSimRelNBW(system, null, i);
            prune_bw(system, bla_brel);
            system=quotient(system, bla_brel);
	    system=finite_removeDead(system);
	 } while(oldsys > system.states.size() || oldsys_trans > system.trans);
    return(system);
    }

